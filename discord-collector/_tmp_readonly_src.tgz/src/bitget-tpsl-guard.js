/**
 * Bitget 开仓止损：止损必须写在市价开仓请求上。
 * 算不出或挂不上止损则不下单。成交后的补挂只是兜底，不再把刚开的仓市价平掉。
 */
import { isLongDirection, isShortDirection } from "./card-direction.js";
import { normalizeExecution } from "./discord-signal-execution.js";
import { widenStopLossToMinPct } from "./card-liquidation-engine.js";
import { envBool, envInt, envStr } from "./env-defaults.js";

const LIQUIDATION_DEFAULT_TP_SL_PCT = 5;
const LIQUIDATION_DEFAULT_TP_PCTS = [0.05, 0.08, 0.12];

/**
 * @param {number} entry
 * @param {boolean} isShort
 * @param {number[]} tps
 * @param {number | null} sl
 */
function applyDefaultTpSl(entry, isShort, tps, sl) {
  const slPct = LIQUIDATION_DEFAULT_TP_SL_PCT / 100;
  /** @type {number[]} */
  const outTps = [...tps];
  let outSl = sl;
  if (!outTps.length) {
    for (const pct of LIQUIDATION_DEFAULT_TP_PCTS) {
      outTps.push(isShort ? entry * (1 - pct) : entry * (1 + pct));
    }
  }
  if (outSl == null) {
    outSl = isShort ? entry * (1 + slPct) : entry * (1 - slPct);
  }
  return { tps: outTps, sl: outSl };
}

/** @param {number} fillPrice @param {string} direction @param {number} pct */
function calcInitialStopLoss(fillPrice, direction, pct) {
  if (!Number.isFinite(fillPrice) || fillPrice <= 0) return null;
  const ratio = pct / 100;
  if (isLongDirection(direction)) return Number((fillPrice * (1 - ratio)).toFixed(8));
  if (isShortDirection(direction)) return Number((fillPrice * (1 + ratio)).toFixed(8));
  return null;
}

/** @param {unknown} resp */
function unwrapBitgetRows(resp) {
  if (!resp || typeof resp !== "object") return [];
  const data = /** @type {Record<string, unknown>} */ (resp).data;
  if (Array.isArray(data)) return data;
  if (data && typeof data === "object") {
    const o = /** @type {Record<string, unknown>} */ (data);
    if (Array.isArray(o.list)) return o.list;
    if (Array.isArray(o.entrustedList)) return o.entrustedList;
    if ("symbol" in o) return [o];
  }
  return [];
}

/** @param {number} ms */
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/** @param {number} price */
export function priceStr(price) {
  if (!Number.isFinite(price) || price <= 0) return "";
  return price.toFixed(8).replace(/0+$/, "").replace(/\.$/, "");
}

/** Bitget 合约 pricePlace/tick 缓存（减轻自动下单路径对 getMixContract 的重复调用） */
const BITGET_CONTRACT_META_TTL_MS = 15 * 60 * 1000;
/** @type {Map<string, { at: number; meta: ReturnType<typeof enrichBitgetContractMeta> }>} */
const bitgetContractMetaCache = new Map();

/**
 * @param {ReturnType<typeof import("./bitget-api.js").createBitgetClient>} client
 * @param {{ symbol: string; productType: string }} p
 */
export async function loadBitgetContractPriceMeta(client, p) {
  const symbol = String(p.symbol ?? "").toUpperCase();
  const productType = String(p.productType ?? "USDT-FUTURES");
  const key = `${productType}:${symbol}`;
  const hit = bitgetContractMetaCache.get(key);
  if (hit && Date.now() - hit.at < BITGET_CONTRACT_META_TTL_MS) return hit.meta;

  /** @type {Record<string, unknown> | null} */
  let raw = null;
  try {
    if (client && typeof client.getMixContract === "function") {
      raw = await client.getMixContract({ symbol, productType });
    }
  } catch {
    raw = null;
  }
  const meta = enrichBitgetContractMeta(raw);
  bitgetContractMetaCache.set(key, { at: Date.now(), meta });
  return meta;
}

/** @param {"long"|"short"|string} holdSide @param {"sl"|"tp"|"entry"} kind */
export function bitgetPriceRoundMode(holdSide, kind) {
  const short = String(holdSide).toLowerCase() === "short";
  if (kind === "sl") return short ? "ceil" : "floor";
  if (kind === "tp") return short ? "floor" : "ceil";
  return "round";
}

/** @param {number} marketPrice @param {number} sl @param {"long"|"short"} holdSide */
export function isValidStopLoss(marketPrice, sl, holdSide) {
  if (!Number.isFinite(marketPrice) || !Number.isFinite(sl) || marketPrice <= 0 || sl <= 0) return false;
  if (holdSide === "long") return sl < marketPrice;
  return sl > marketPrice;
}

/** @param {number} marketPrice @param {number} tp @param {"long"|"short"} holdSide */
export function isValidTakeProfit(marketPrice, tp, holdSide) {
  if (!Number.isFinite(marketPrice) || !Number.isFinite(tp) || marketPrice <= 0 || tp <= 0) return false;
  if (holdSide === "long") return tp > marketPrice;
  return tp < marketPrice;
}

export function bitgetRequireTpslEnabled() {
  return envBool("BITGET_REQUIRE_TPSL", true);
}

/**
 * 止损挂不上时的策略。默认 skip：拒绝无止损开仓。
 * 旧值 close 不再表示「先开仓再平掉」；与 skip 相同。
 * @returns {"skip"|"alert"}
 */
export function bitgetNakedPositionAction() {
  const v = envStr("BITGET_NAKED_POSITION_ACTION", "skip", ["skip", "alert", "close"]).toLowerCase();
  return v === "alert" ? "alert" : "skip";
}

export function bitgetTpslVerifyWindowMs() {
  const sec = envInt("BITGET_TPSL_VERIFY_SEC", 8, { min: 2, max: 60 });
  return sec * 1000;
}

export function bitgetTpslRepairRetries() {
  return envInt("BITGET_TPSL_REPAIR_RETRIES", 3, { min: 1, max: 10 });
}

/** @typedef {"sl_breached"|"precision"|"transient"|"hold_side"|"request_param"|"unknown"} TpslRepairErrorCategory */

/**
 * @param {string} message
 * @param {"long"|"short"|string} holdSide
 * @returns {TpslRepairErrorCategory}
 */
export function classifyBitgetTpslRepairError(message, holdSide) {
  const m = String(message ?? "").toLowerCase();
  const side = String(holdSide ?? "").toLowerCase();

  if (
    /stop loss price of the long position should be less than/i.test(m) ||
    /stop loss price of the short position should be greater than/i.test(m) ||
    /stop loss.*should be less than the current price/i.test(m) ||
    /stop loss.*should be greater than the current price/i.test(m) ||
    /sl price.*invalid.*current/i.test(m) ||
    /already.*trigger/i.test(m)
  ) {
    return "sl_breached";
  }
  if (side === "long" && /stop loss.*greater than.*current|sl.*above.*mark/i.test(m)) {
    return "sl_breached";
  }
  if (side === "short" && /stop loss.*less than.*current|sl.*below.*mark/i.test(m)) {
    return "sl_breached";
  }

  if (/429|rate limit|too many requests|timeout|timed out|etimedout|econnreset|network|temporarily unavailable/i.test(m)) {
    return "transient";
  }
  if (/position.*not exist|no position|position does not exist|order.*not exist|not found position/i.test(m)) {
    return "transient";
  }

  if (/holdside|hold side|position side|posside|position mode|unilateral|hedge mode|one-way|two-way/i.test(m)) {
    return "hold_side";
  }

  if (
    /precision|priceplace|priceendstep|price step|tick size|minimum size|volume place|sizemultiplier|decimal|multiple of|parameter verification/i.test(
      m
    )
  ) {
    return "precision";
  }

  if (
    /preset(?:sl|stoploss)excuteprice|presetstop(?:surplus|loss)executeprice|stopsurplusexecuteprice|stoplossexecuteprice|execute\s*price.*must|executeprice.*greater than\s*0|does not meet the specification/i.test(
      m
    )
  ) {
    return "request_param";
  }

  return "unknown";
}

/**
 * @param {Record<string, unknown> | null | undefined} raw
 * @param {ReturnType<typeof import("./bitget-order-from-signal.js").parseBitgetContractMeta>} [base]
 */
export function enrichBitgetContractMeta(raw, base) {
  const b = base ?? {};
  const o = raw && typeof raw === "object" ? /** @type {Record<string, unknown>} */ (raw) : {};
  const pricePlaceRaw = o.pricePlace ?? b.pricePlace;
  const priceEndRaw = o.priceEndStep ?? o.priceStep ?? b.priceEndStep ?? b.priceStep;
  const placeNum = Number(pricePlaceRaw);
  const endNum = Number(priceEndRaw);
  const hasPlace =
    pricePlaceRaw != null && pricePlaceRaw !== "" && Number.isFinite(placeNum) && placeNum >= 0;
  const hasEnd = priceEndRaw != null && priceEndRaw !== "" && Number.isFinite(endNum) && endNum > 0;
  const pricePlace = hasPlace ? Math.min(8, Math.floor(placeNum)) : hasEnd && endNum < 1 ? decimalsOfTick(endNum) : null;
  const priceEndStep = hasEnd ? endNum : 0;
  const tickProbe = bitgetTriggerTick({
    pricePlace: pricePlace ?? undefined,
    priceEndStep,
  });
  return {
    minTradeNum: Number(o.minTradeNum ?? b.minTradeNum ?? 0) || 0,
    minTradeUsdt: Number(o.minTradeUSDT ?? o.minTradeUsdt ?? b.minTradeUsdt ?? 0) || 0,
    volumePlace: Number(o.volumePlace ?? b.volumePlace ?? 8) || 8,
    sizeMultiplier: Number(o.sizeMultiplier ?? b.sizeMultiplier ?? 0) || 0,
    pricePlace: pricePlace ?? 2,
    priceEndStep,
    priceTickKnown: tickProbe > 0,
    priceTick: tickProbe,
  };
}

/** @param {number} tick */
function decimalsOfTick(tick) {
  if (!(tick > 0)) return 0;
  const s = tick.toFixed(8).replace(/0+$/, "").replace(/\.$/, "");
  const i = s.indexOf(".");
  return i < 0 ? 0 : Math.min(8, s.length - i - 1);
}

/**
 * Bitget `priceEndStep` 是最后一位小数的步长（常见 1 或 5），tick = step × 10^(-pricePlace)。
 * 小于 1 的 priceEndStep 视为绝对 tick（旧调用 / 单测）。
 * @param {{ pricePlace?: number, priceEndStep?: number } | null | undefined} meta
 */
export function bitgetTriggerTick(meta) {
  const placeRaw = Number(meta?.pricePlace);
  const endRaw = Number(meta?.priceEndStep);
  const place = Number.isFinite(placeRaw) && placeRaw >= 0 ? Math.min(8, Math.floor(placeRaw)) : null;
  const end = Number.isFinite(endRaw) && endRaw > 0 ? endRaw : 0;
  if (place != null && end >= 1) return end * 10 ** -place;
  if (end > 0 && end < 1) return end;
  if (place != null) return 10 ** -place;
  return 0;
}

/**
 * @param {number} scaled
 * @param {number} decimals
 */
function formatScaledInt(scaled, decimals) {
  if (!(scaled > 0)) return "";
  const d = Math.min(8, Math.max(0, decimals));
  if (d === 0) return String(Math.trunc(scaled));
  const scale = 10 ** d;
  const whole = Math.trunc(scaled / scale);
  const frac = String(Math.abs(scaled % scale)).padStart(d, "0").replace(/0+$/, "");
  return frac ? `${whole}.${frac}` : String(whole);
}

/**
 * @param {number} scaled
 * @param {number} tickScaled
 * @param {"round"|"floor"|"ceil"} mode
 */
function alignScaledToTick(scaled, tickScaled, mode) {
  if (!(tickScaled > 0)) {
    if (mode === "floor") return Math.floor(scaled + 1e-12);
    if (mode === "ceil") return Math.ceil(scaled - 1e-12);
    return Math.round(scaled);
  }
  const q = scaled / tickScaled;
  if (mode === "floor") return Math.floor(q + 1e-12) * tickScaled;
  if (mode === "ceil") return Math.ceil(q - 1e-12) * tickScaled;
  return Math.round(q) * tickScaled;
}

/**
 * 按合约 tick 取整，并用整数刻度格式化，避免 0.40015500000000004 这类二进制尾数。
 * 默认 nearest；SL/TP 可用 floor/ceil 以免相对 mark 的方向被 tick 取整「放宽」。
 * @param {number} price
 * @param {{ pricePlace?: number; priceEndStep?: number }} meta
 * @param {{ mode?: "round"|"floor"|"ceil" }} [opts]
 */
export function roundBitgetTriggerPrice(price, meta, opts = {}) {
  if (!Number.isFinite(price) || price <= 0) return "";
  const mode = opts.mode ?? "round";
  const placeRaw = Number(meta?.pricePlace);
  const place = Number.isFinite(placeRaw) && placeRaw >= 0 ? Math.min(8, Math.floor(placeRaw)) : 8;
  const tick = bitgetTriggerTick(meta);
  const decimals = Math.min(8, Math.max(place, decimalsOfTick(tick)));
  const scale = 10 ** decimals;
  let scaled = price * scale;
  if (tick > 0) {
    const tickScaled = Math.round(tick * scale);
    if (tickScaled > 0) {
      scaled = alignScaledToTick(scaled, tickScaled, mode);
    } else {
      scaled = Math.round(scaled);
    }
  } else {
    scaled = alignScaledToTick(scaled, 0, mode);
  }
  scaled = Math.round(scaled + 1e-9);
  return formatScaledInt(scaled, decimals);
}

/**
 * @param {unknown} raw
 * @param {{ pricePlace?: number, priceEndStep?: number, priceTickKnown?: boolean } | null | undefined} meta
 * @param {number} [forcedTick]
 */
export function sanitizeBitgetTriggerPrice(raw, meta, forcedTick = 0, opts = {}) {
  const n = Number(String(raw ?? "").replace(/[^\d.]/g, ""));
  if (!Number.isFinite(n) || n <= 0) return "";
  if (forcedTick > 0) {
    return roundBitgetTriggerPrice(
      n,
      {
        pricePlace: decimalsOfTick(forcedTick),
        priceEndStep: forcedTick,
      },
      opts
    );
  }
  const tick = bitgetTriggerTick(meta);
  if (tick > 0) return roundBitgetTriggerPrice(n, meta, opts);
  return priceStr(n);
}

/**
 * @param {{
 *   stopLossRaw: unknown;
 *   takeProfitRaw: unknown;
 *   meta: ReturnType<typeof enrichBitgetContractMeta> | null;
 *   holdSide: "long"|"short"|string;
 *   forcedTick?: number;
 * }} input
 */
export function sanitizeBitgetOpenPresetPrices(input) {
  const slMode = bitgetPriceRoundMode(input.holdSide, "sl");
  const tpMode = bitgetPriceRoundMode(input.holdSide, "tp");
  const forcedTick = Number(input.forcedTick) > 0 ? Number(input.forcedTick) : 0;
  const meta = input.meta;
  return {
    stopLossStr: sanitizeBitgetTriggerPrice(input.stopLossRaw, meta, forcedTick, { mode: slMode }),
    takeProfitStr: sanitizeBitgetTriggerPrice(input.takeProfitRaw, meta, forcedTick, { mode: tpMode }),
  };
}

/** @param {unknown} message */
export function tickFromBitgetPriceError(message) {
  const m = String(message ?? "").match(/multiple of\s+([0-9]*\.?[0-9]+)/i);
  if (!m) return 0;
  const n = Number(m[1]);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

/**
 * @param {ReturnType<typeof import("./bitget-api.js").createBitgetClient>} client
 * @param {{
 *   symbol: string;
 *   productType: string;
 *   fetchMark?: () => Promise<number | null>;
 * }} ctx
 */
async function fetchMarkForRepair(client, ctx) {
  if (ctx.fetchMark) {
    const m = await ctx.fetchMark();
    if (m != null && m > 0) return m;
  }
  try {
    const ticker = await client.getMixTicker({ symbol: ctx.symbol, productType: ctx.productType });
    const p = Number(ticker?.markPrice ?? ticker?.lastPr ?? 0);
    if (Number.isFinite(p) && p > 0) return p;
  } catch {
    /* ignore */
  }
  return 0;
}

/**
 * @param {{
 *   mark: number;
 *   holdSide: "long"|"short";
 *   direction: string;
 *   initialSlPct: number;
 *   parsed?: Record<string, unknown>;
 *   executionJson?: unknown;
 *   signalStopLossStr: string;
 *   signalTakeProfitStr: string;
 *   contractMeta?: ReturnType<typeof enrichBitgetContractMeta> | null;
 *   forcePrecisionRound?: boolean;
 *   sizeStr: string;
 * }} input
 */
export function resolveRepairTpslLevels(input) {
  const holdSide = input.holdSide;
  const mark = input.mark;

  let slNum = Number(String(input.signalStopLossStr).replace(/[^\d.]/g, ""));
  let tpNum = Number(String(input.signalTakeProfitStr).replace(/[^\d.]/g, ""));
  const markOnly =
    input.parsed?.tradeTpslFromMark === true || input.forceMarkOnlyTpsl === true;
  const useSignalSl =
    !markOnly && Number.isFinite(slNum) && slNum > 0 && isValidStopLoss(mark, slNum, holdSide);
  const useSignalTp =
    !markOnly && Number.isFinite(tpNum) && tpNum > 0 && isValidTakeProfit(mark, tpNum, holdSide);

  const resolved = resolveOpenTpslPrices({
    parsed: input.parsed ?? {},
    executionJson: input.executionJson,
    fillPrice: mark,
    direction: input.direction,
    initialSlPct: input.initialSlPct,
    allowMissingTakeProfit: true,
  });

  if (useSignalSl) {
    slNum = widenStopLossToMinPct(
      mark,
      slNum,
      holdSide === "short",
      input.initialSlPct
    );
  }
  let stopLossStr = useSignalSl ? priceStr(slNum) : resolved.stopLossStr;
  let takeProfitStr = useSignalTp ? priceStr(tpNum) : resolved.takeProfitStr;

  if (input.contractMeta && (bitgetTriggerTick(input.contractMeta) > 0 || input.forcePrecisionRound)) {
    const slMode = bitgetPriceRoundMode(holdSide, "sl");
    const tpMode = bitgetPriceRoundMode(holdSide, "tp");
    const roundedSl = roundBitgetTriggerPrice(Number(stopLossStr), input.contractMeta, { mode: slMode });
    const roundedTp = roundBitgetTriggerPrice(Number(takeProfitStr), input.contractMeta, { mode: tpMode });
    if (roundedSl) stopLossStr = roundedSl;
    if (roundedTp) takeProfitStr = roundedTp;
  }

  return {
    stopLossStr,
    takeProfitStr,
    usedSignalSl: useSignalSl,
    usedSignalTp: useSignalTp,
    mark,
  };
}

/**
 * @param {ReturnType<typeof import("./bitget-api.js").createBitgetClient>} client
 * @param {{
 *   symbol: string;
 *   productType: string;
 *   marginCoin: string;
 *   holdSide: string;
 *   size: string;
 *   stopLossStr: string;
 *   takeProfitStr: string;
 *   cardId: number;
 *   direction?: string;
 *   initialSlPct?: number;
 *   parsed?: Record<string, unknown>;
 *   executionJson?: unknown;
 *   fetchMark?: () => Promise<number | null>;
 * }} ctx
 * @param {Record<string, unknown>} record
 */
export async function repairBitgetPositionTpsl(client, ctx, record) {
  const maxRetries = bitgetTpslRepairRetries();
  const backoffMs = [1000, 2000, 4000];
  /** @type {{ attempts: Array<Record<string, unknown>>; repaired?: boolean }} */
  const repair = { attempts: [] };
  record.tpslRepair = repair;

  let forcePrecision = false;
  let forceMarkOnly = false;
  let closeImmediately = false;
  /** @type {TpslRepairErrorCategory} */
  let lastCategory = "unknown";
  let lastError = "";
  let lastMark = 0;

  const holdSide = /** @type {"long"|"short"} */ (
    ctx.holdSide === "short" || ctx.holdSide === "sell" ? "short" : "long"
  );
  const direction =
    ctx.direction ?? (holdSide === "short" ? "做空" : "做多");
  const initialSlPct = Number(ctx.initialSlPct) > 0 ? Number(ctx.initialSlPct) : 5;

  let sizeStr = ctx.size;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    lastMark = await fetchMarkForRepair(client, ctx);
    if (!(lastMark > 0)) {
      lastError = "no_market_price";
      lastCategory = "transient";
      repair.attempts.push({
        attempt,
        at: new Date().toISOString(),
        ok: false,
        category: lastCategory,
        error: lastError,
      });
      if (attempt < maxRetries) await sleep(backoffMs[Math.min(attempt - 1, backoffMs.length - 1)]);
      continue;
    }

    /** @type {ReturnType<typeof enrichBitgetContractMeta> | null} */
    let contractMeta = null;
    try {
      if (typeof client.getMixContract === "function") {
        const raw = await client.getMixContract({ symbol: ctx.symbol, productType: ctx.productType });
        contractMeta = enrichBitgetContractMeta(raw);
      } else {
        contractMeta = enrichBitgetContractMeta(null);
      }
    } catch {
      contractMeta = enrichBitgetContractMeta(null);
    }

    if (forcePrecision && contractMeta?.sizeMultiplier > 0) {
      const step = contractMeta.sizeMultiplier;
      const vp = contractMeta.volumePlace ?? 8;
      const n = Math.floor(Number(sizeStr) / step + 1e-12) * step;
      if (n > 0) sizeStr = priceStr(Number(n.toFixed(Math.min(8, vp))));
    }

    const levels = resolveRepairTpslLevels({
      mark: lastMark,
      holdSide,
      direction,
      initialSlPct,
      parsed: ctx.parsed,
      executionJson: ctx.executionJson,
      signalStopLossStr: ctx.stopLossStr,
      signalTakeProfitStr: ctx.takeProfitStr,
      contractMeta,
      forcePrecisionRound: forcePrecision,
      forceMarkOnlyTpsl: forceMarkOnly,
      sizeStr,
    });

    /** @type {Record<string, unknown>} */
    const attemptRec = {
      attempt,
      at: new Date().toISOString(),
      mark: lastMark,
      stopLossStr: levels.stopLossStr,
      takeProfitStr: levels.takeProfitStr,
      size: sizeStr,
      usedSignalSl: levels.usedSignalSl,
      usedSignalTp: levels.usedSignalTp,
      precisionRound: forcePrecision,
    };

    try {
      const tpStr = levels.takeProfitStr;
      const tpNum = Number(tpStr);
      const includeTp = Boolean(tpStr) && isValidTakeProfit(lastMark, tpNum, holdSide);
      const posResp = await client.withHoldSideFallback(
        (hs) =>
          client.placePosTpsl({
            symbol: ctx.symbol,
            productType: ctx.productType,
            marginCoin: ctx.marginCoin,
            holdSide: hs,
            stopLossTriggerPrice: levels.stopLossStr,
            stopLossExecutePrice: levels.stopLossStr,
            ...(includeTp
              ? {
                  stopSurplusTriggerPrice: tpStr,
                  stopSurplusExecutePrice: tpStr,
                  stopSurplusSize: sizeStr,
                  stopSurplusClientOid: `dc-tp-verify-${ctx.cardId}-${Date.now()}-a${attempt}`,
                }
              : {}),
            stopLossClientOid: `dc-sl-verify-${ctx.cardId}-${Date.now()}-a${attempt}`,
          }),
        ctx.holdSide
      );
      attemptRec.ok = true;
      attemptRec.response = posResp;
      repair.attempts.push(attemptRec);

      await sleep(500);
      const inspect = await inspectBitgetPositionTpsl(client, ctx);
      attemptRec.verifyAfter = inspect;
      if (inspect.ok) {
        repair.repaired = true;
        return { ok: true, inspect, repair };
      }
      lastError = "verify_still_missing_tpsl";
      lastCategory = "transient";
      attemptRec.verifyMissing = true;
    } catch (e) {
      const msg = String(/** @type {Error} */ (e).message ?? e);
      lastError = msg;
      lastCategory = classifyBitgetTpslRepairError(msg, holdSide);
      attemptRec.ok = false;
      attemptRec.error = msg;
      attemptRec.category = lastCategory;
      repair.attempts.push(attemptRec);

      if (lastCategory === "sl_breached") {
        // 预设止损相对现价无效：用最新标记价重算计划止损，不立刻市价平仓
        forceMarkOnly = true;
        forcePrecision = true;
      }
      if (lastCategory === "precision") {
        forcePrecision = true;
      }
    }

    if (closeImmediately) break;
    if (attempt < maxRetries) {
      await sleep(backoffMs[Math.min(attempt - 1, backoffMs.length - 1)]);
    }
  }

  if (!repair.closeReason) {
    const allRequestParam =
      repair.attempts.length > 0 && repair.attempts.every((a) => a.category === "request_param");
    repair.closeReason = closeImmediately
      ? "sl_breached"
      : allRequestParam
        ? "request_param_exhausted"
        : "retries_exhausted";
  }

  return {
    ok: false,
    repair,
    closeImmediately,
    closeReason: repair.closeReason,
    lastCategory,
    lastError,
    mark: lastMark,
  };
}

/**
 * @param {ReturnType<typeof import("./logger.js").createLogger>} log
 * @param {{
 *   symbol: string;
 *   holdSide: string;
 *   cardId: number;
 *   category: string;
 *   lastError: string;
 *   mark: number;
 *   attempts: Array<Record<string, unknown>>;
 *   closeImmediately: boolean;
 *   action: "close"|"alert";
 * }} details
 */
export function formatBitgetNakedPositionAlert(details) {
  const lines = [
    details.action === "close" ? "Bitget 裸仓已平" : "Bitget 裸仓告警",
    `标的 ${details.symbol} ${details.holdSide} card=#${details.cardId}`,
    `原因分类: ${details.category}`,
    details.closeImmediately ? "（止损已被穿越 / SL 相对现价无效，立即平仓）" : "（补挂重试已用尽）",
    `原始错误: ${details.lastError || "—"}`,
    `标记价: ${details.mark > 0 ? details.mark : "—"}`,
    `尝试记录: ${JSON.stringify(details.attempts)}`,
  ];
  return lines.join("\n");
}

/**
 * 从信号或默认规则解析开仓用 SL/TP（含多档 TP 字符串列表）。
 * @param {{
 *   parsed: Record<string, unknown>;
 *   executionJson?: unknown;
 *   fillPrice: number;
 *   direction: string;
 *   initialSlPct: number;
 *   contractMeta?: ReturnType<typeof enrichBitgetContractMeta> | null;
 *   preserveSignalStop?: boolean;
 *   allowMissingTakeProfit?: boolean;
 *   markOnlyTpsl?: boolean;
 * }} input
 */
function usesMarkOnlyTpsl(input) {
  return (
    input.markOnlyTpsl === true ||
    input.forceMarkOnlyTpsl === true ||
    input.parsed?.tradeTpslFromMark === true
  );
}

/** 空字符串、0 不算有效止损，避免 planned.stopLossPrice="" 盖掉信号里的止损。 */
function firstPositivePrice(...vals) {
  for (const v of vals) {
    if (v == null) continue;
    const s = String(v).trim();
    if (!s || s === "0") continue;
    const n = Number(s.replace(/[^\d.]/g, ""));
    if (Number.isFinite(n) && n > 0) return n;
  }
  return null;
}

/** @param {unknown[]} raw */
function positivePrices(raw) {
  return (Array.isArray(raw) ? raw : [])
    .map((p) => Number(String(p ?? "").replace(/[^\d.]/g, "")))
    .filter((n) => Number.isFinite(n) && n > 0);
}

export function resolveOpenTpslPrices(input) {
  const ex = normalizeExecution(input.executionJson ?? null, input.parsed);
  const direction = input.direction;
  const fillPrice = input.fillPrice;
  const isShort = isShortDirection(direction);
  const markOnly = usesMarkOnlyTpsl(input);
  const preserveSignalStop = input.preserveSignalStop === true;
  const allowMissingTp = input.allowMissingTakeProfit === true || preserveSignalStop;
  const slPct = Number(input.initialSlPct) > 0 ? Number(input.initialSlPct) : 5;

  let signalSl = null;
  /** @type {number[]} */
  let tpNums = [];

  if (!markOnly || preserveSignalStop) {
    signalSl = firstPositivePrice(
      ex.planned?.stopLossPrice,
      input.parsed?.stopLoss,
      input.parsed?.stop_loss
    );
    const plannedTps = positivePrices(ex.planned?.takeProfitPrices);
    const parsedTps = positivePrices(input.parsed?.takeProfits);
    tpNums = plannedTps.length ? plannedTps : parsedTps;
  }

  let slNum = signalSl;
  if (!(slNum > 0)) {
    slNum = calcInitialStopLoss(fillPrice, direction, slPct);
  } else if (!preserveSignalStop) {
    slNum = widenStopLossToMinPct(fillPrice, slNum, isShort, slPct);
  }

  if (!allowMissingTp && !tpNums.length) {
    const applied = applyDefaultTpSl(fillPrice, isShort, [], slNum);
    tpNums = applied.tps;
    if (!(slNum > 0)) slNum = applied.sl;
  }

  const takeProfits = tpNums.map((n) => priceStr(n)).filter(Boolean);
  const stopLoss = priceStr(slNum);
  const firstTp = takeProfits[0] ?? "";

  const contractMeta = input.contractMeta;
  if (contractMeta && bitgetTriggerTick(contractMeta) > 0) {
    const holdSide = isShort ? "short" : "long";
  /** @type {string[]} */
    const roundedTps = takeProfits.map((tp) =>
      sanitizeBitgetTriggerPrice(tp, contractMeta, 0, { mode: bitgetPriceRoundMode(holdSide, "tp") })
    );
    const roundedSl = sanitizeBitgetTriggerPrice(stopLoss, contractMeta, 0, {
      mode: bitgetPriceRoundMode(holdSide, "sl"),
    });
    if (roundedSl) {
      return {
        stopLossPrice: Number(roundedSl),
        takeProfitPrice: Number(roundedTps[0] ?? 0),
        stopLossStr: roundedSl,
        takeProfitStr: roundedTps[0] ?? "",
        takeProfits: roundedTps.filter(Boolean),
      };
    }
  }

  return {
    stopLossPrice: slNum,
    takeProfitPrice: tpNums[0] ?? 0,
    stopLossStr: stopLoss,
    takeProfitStr: firstTp,
    takeProfits,
  };
}

/**
 * @param {ReturnType<typeof import("./bitget-api.js").createBitgetClient>} client
 * @param {{
 *   symbol: string;
 *   productType: string;
 *   marginCoin?: string;
 *   holdSide: string;
 * }} p
 */
export async function inspectBitgetPositionTpsl(client, p) {
  const symbol = String(p.symbol).toUpperCase();
  const wantSide = String(p.holdSide ?? "").toLowerCase();
  const sideAlts = new Set(
    wantSide === "long" || wantSide === "buy"
      ? ["long", "buy"]
      : wantSide === "short" || wantSide === "sell"
        ? ["short", "sell"]
        : []
  );

  let hasSl = false;
  let hasTp = false;

  try {
    const posResp = await client.getSinglePosition({
      symbol,
      productType: p.productType,
      marginCoin: p.marginCoin ?? "USDT",
    });
    for (const row of unwrapBitgetRows(posResp)) {
      if (!row || typeof row !== "object") continue;
      const r = /** @type {Record<string, unknown>} */ (row);
      if (String(r.symbol ?? "").toUpperCase() !== symbol) continue;
      const hs = String(r.holdSide ?? "").toLowerCase();
      if (sideAlts.size && hs && !sideAlts.has(hs)) continue;

      const slFields = [r.stopLoss, r.stopLossTriggerPrice, r.presetStopLossPrice, r.stopLossPrice];
      const tpFields = [r.takeProfit, r.stopSurplusTriggerPrice, r.presetStopSurplusPrice, r.takeProfitPrice];
      for (const v of slFields) {
        const n = Number(v);
        if (v != null && String(v) !== "" && String(v) !== "0" && (Number.isFinite(n) ? n > 0 : true)) {
          hasSl = true;
          break;
        }
      }
      for (const v of tpFields) {
        const n = Number(v);
        if (v != null && String(v) !== "" && String(v) !== "0" && (Number.isFinite(n) ? n > 0 : true)) {
          hasTp = true;
          break;
        }
      }
    }
  } catch {
    /* plan 查询兜底 */
  }

  if (!hasSl || !hasTp) {
    try {
      const planResp = await client.getOrdersPlanPending({
        productType: p.productType,
        symbol,
      });
      for (const row of unwrapBitgetRows(planResp)) {
        if (!row || typeof row !== "object") continue;
        const r = /** @type {Record<string, unknown>} */ (row);
        const planType = String(r.planType ?? r.plan_type ?? "").toLowerCase();
        const hs = String(r.holdSide ?? r.posSide ?? "").toLowerCase();
        if (sideAlts.size && hs && !sideAlts.has(hs)) continue;
        if (planType.includes("loss")) hasSl = true;
        if (planType.includes("profit") || planType.includes("surplus")) hasTp = true;
      }
    } catch {
      /* ignore */
    }
  }

  return { hasSl, hasTp, ok: hasSl };
}

/**
 * 市价开仓：请求本身必须带 preset 止损。信号有止盈才附带。
 * 止损无效时不调用 placeOrder。交易所拒绝时只重试仍带止损的同一路径。
 * @param {ReturnType<typeof import("./bitget-api.js").createBitgetClient>} client
 * @param {{
 *   openBase: Record<string, unknown>;
 *   symbol: string;
 *   productType: string;
 *   marginCoin: string;
 *   holdSide: "long"|"short";
 *   direction: string;
 *   size: string;
 *   initialSlPct: number;
 *   stopLossStr?: string;
 *   takeProfitStr?: string;
 *   fetchMark: () => Promise<number | null>;
 *   parsed?: Record<string, unknown>;
 *   executionJson?: unknown;
 *   maxPresetAttempts?: number;
 * }} p
 */
export async function placeBitgetOpenWithPresets(client, p) {
  const holdSide = p.holdSide;
  const maxPresetAttempts = p.maxPresetAttempts ?? 3;
  /** @type {string[]} */
  const presetErrors = [];
  let forcedTick = 0;
  let placeAttempted = false;
  const slPct = Number(p.initialSlPct) > 0 ? Number(p.initialSlPct) : 5;

  for (let presetAttempt = 1; presetAttempt <= maxPresetAttempts; presetAttempt++) {
    const contractMeta = await loadBitgetContractPriceMeta(client, {
      symbol: p.symbol,
      productType: p.productType,
    });
    const mark = (await p.fetchMark()) ?? 0;
    if (!(mark > 0)) {
      presetErrors.push(`preset ${presetAttempt}: no mark price`);
      if (presetAttempt < maxPresetAttempts) await sleep(300 * presetAttempt);
      continue;
    }

    const resolved = resolveOpenTpslPrices({
      parsed: p.parsed ?? {},
      executionJson: p.executionJson,
      fillPrice: mark,
      direction: p.direction,
      initialSlPct: slPct,
      contractMeta,
      preserveSignalStop: true,
      allowMissingTakeProfit: true,
    });
    const presetPrices = sanitizeBitgetOpenPresetPrices({
      stopLossRaw: resolved.stopLossStr,
      takeProfitRaw: resolved.takeProfitStr,
      meta: contractMeta,
      holdSide,
      forcedTick,
    });
    const slStr = presetPrices.stopLossStr;
    let tpStr = presetPrices.takeProfitStr;
    const slNum = Number(slStr);
    if (tpStr && !isValidTakeProfit(mark, Number(tpStr), holdSide)) {
      presetErrors.push(`preset ${presetAttempt}: drop invalid tp ${tpStr} vs mark ${mark}`);
      tpStr = "";
    }

    if (!slStr || !isValidStopLoss(mark, slNum, holdSide)) {
      presetErrors.push(`preset ${presetAttempt}: stop unavailable vs mark ${mark} sl=${slStr || "—"}`);
      if (presetAttempt < maxPresetAttempts) await sleep(300 * presetAttempt);
      continue;
    }

    /** @type {Record<string, unknown>} */
    const order = {
      ...p.openBase,
      orderType: "market",
      presetStopLossPrice: slStr,
      presetStopLossExecutePrice: slStr,
    };
    delete order.price;
    if (tpStr) {
      order.presetStopSurplusPrice = tpStr;
      order.presetStopSurplusExecutePrice = tpStr;
    }

    placeAttempted = true;
    try {
      const openResp = await client.placeOrder(order);
      return {
        ok: true,
        openResp,
        presetStopLossPrice: slStr,
        presetStopSurplusPrice: tpStr,
        markUsed: mark,
        presetAttempt,
        orderSent: true,
      };
    } catch (e) {
      const msg = String(/** @type {Error} */ (e).message ?? e);
      presetErrors.push(`preset ${presetAttempt}: ${msg}`);
      const parsedTick = tickFromBitgetPriceError(msg);
      if (parsedTick > 0) forcedTick = parsedTick;
      if (classifyBitgetTpslRepairError(msg, holdSide) === "precision") {
        bitgetContractMetaCache.delete(`${p.productType}:${String(p.symbol).toUpperCase()}`);
      }
      if (presetAttempt < maxPresetAttempts) await sleep(350 * presetAttempt);
    }
  }

  return {
    ok: false,
    reason: placeAttempted ? "preset_open_failed" : "stop_loss_unavailable",
    presetErrors,
    orderSent: false,
  };
}

/**
 * @param {string} totalSize
 * @param {string[]} takeProfits
 * @param {number[]} ratios
 * @param {Record<string, unknown>} contractMeta
 * @param {(size: number, meta: Record<string, unknown>, opts: { mode?: string }) => string} formatOrderSize
 */
export function buildTpPlans(totalSize, takeProfits, ratios, contractMeta, formatOrderSize) {
  const total = Number(totalSize);
  if (!Number.isFinite(total) || total <= 0) return [];

  /** @type {Array<Record<string, unknown>>} */
  const plans = [];
  let remaining = total;
  const levels = Math.min(takeProfits.length, ratios.length);

  for (let i = 0; i < levels; i++) {
    const isLast = i === levels - 1;
    let tpSizeStr;
    if (isLast) {
      tpSizeStr = formatOrderSize(remaining, contractMeta, { mode: "floor" });
    } else {
      tpSizeStr = formatOrderSize(total * ratios[i], contractMeta, { mode: "floor" });
      const tpNum = Number(tpSizeStr);
      if (tpNum > 0) remaining = Math.max(0, remaining - tpNum);
    }
    if (!tpSizeStr) continue;
    plans.push({
      level: i + 1,
      price: takeProfits[i],
      size: tpSizeStr,
      ratio: isLast ? 1 : ratios[i],
    });
  }
  return plans;
}

/**
 * @param {ReturnType<typeof import("./bitget-api.js").createBitgetClient>} client
 * @param {{
 *   symbol: string;
 *   productType: string;
 *   marginCoin: string;
 *   holdSide: string;
 *   size: string;
 *   takeProfits: string[];
 *   tpPartialRatios: number[];
 *   contractMeta: Record<string, unknown>;
 *   cardId: number;
 *   skipFirstLevel?: boolean;
 * }} p
 */
export async function placeBitgetPartialTakeProfits(client, p) {
  const { formatOrderSize } = await import("./bitget-order-from-signal.js");
  const tps = p.takeProfits.map((x) => String(x).replace(/[^\d.]/g, "")).filter(Boolean);
  const startIdx = p.skipFirstLevel && tps.length > 1 ? 1 : 0;
  const sliceTps = tps.slice(startIdx);
  if (!sliceTps.length) return { tpResults: [] };

  const ratios = p.tpPartialRatios.slice(startIdx);
  const plans = buildTpPlans(p.size, sliceTps, ratios.length ? ratios : [1], p.contractMeta, formatOrderSize);
  /** @type {Array<Record<string, unknown>>} */
  const tpResults = [];

  const priceMeta = enrichBitgetContractMeta(p.contractMeta);
  const tpMode = bitgetPriceRoundMode(p.holdSide, "tp");
  for (const tp of plans) {
    const triggerPrice =
      sanitizeBitgetTriggerPrice(tp.price, priceMeta, 0, { mode: tpMode }) ||
      String(tp.price).replace(/[^\d.]/g, "");
    if (!triggerPrice) continue;
    try {
      const resp = await client.withHoldSideFallback(
        (hs) =>
          client.placeTpslOrder({
            symbol: p.symbol,
            productType: p.productType,
            marginCoin: p.marginCoin,
            planType: "profit_plan",
            triggerPrice,
            holdSide: hs,
            size: String(tp.size),
            clientOid: `dc-tp${tp.level}-${p.cardId}-${Date.now()}`,
          }),
        p.holdSide
      );
      tpResults.push({ ...tp, orderId: resp?.data?.orderId ?? resp?.data?.planId, response: resp });
    } catch (e) {
      tpResults.push({ ...tp, error: String(/** @type {Error} */ (e).message ?? e) });
    }
  }
  return { tpResults };
}

/**
 * @param {ReturnType<typeof import("./logger.js").createLogger>} log
 * @param {string} text
 */
/** Bitget 下单/补挂/裸仓处置结果仅写本地日志，不推送到 Telegram 交易群。 */
export async function sendBitgetTradeTelegramAlert(_log, _text) {
  /* intentionally no-op — callers use log.warn for local retention */
}

/**
 * 开仓后确认止损是否可见。缺失时才补挂（兜底，不是止损的首次创建）。
 * 不再因为校验失败把刚开的仓市价平掉。
 * @param {ReturnType<typeof import("./bitget-api.js").createBitgetClient>} client
 * @param {ReturnType<typeof import("./logger.js").createLogger>} log
 * @param {{
 *   symbol: string;
 *   productType: string;
 *   marginCoin: string;
 *   holdSide: string;
 *   size: string;
 *   stopLossStr: string;
 *   takeProfitStr: string;
 *   cardId: number;
 * }} ctx
 * @param {Record<string, unknown>} record
 */
export async function ensureBitgetPositionTpslAfterOpen(client, log, ctx, record) {
  if (!bitgetRequireTpslEnabled()) {
    record.tpslVerification = { skipped: true, reason: "BITGET_REQUIRE_TPSL=0" };
    return { ok: true, record };
  }

  const deadline = Date.now() + bitgetTpslVerifyWindowMs();
  let lastInspect = { hasSl: false, hasTp: false, ok: false };

  while (Date.now() < deadline) {
    lastInspect = await inspectBitgetPositionTpsl(client, ctx);
    if (lastInspect.ok) {
      record.tpslVerification = { ok: true, at: new Date().toISOString(), ...lastInspect };
      return { ok: true, record };
    }
    await sleep(500);
  }

  record.tpslVerification = {
    ok: false,
    preRepair: lastInspect,
    at: new Date().toISOString(),
  };

  const repairResult = await repairBitgetPositionTpsl(client, ctx, record);
  if (repairResult.ok) {
    record.tpslVerification = {
      ok: true,
      repaired: true,
      at: new Date().toISOString(),
      ...repairResult.inspect,
    };
    return { ok: true, record };
  }

  const action = bitgetNakedPositionAction();
  const repair = repairResult.repair ?? { attempts: [] };
  const category = repairResult.closeReason ?? repairResult.lastCategory ?? "unknown";
  const alertDetails = {
    symbol: ctx.symbol,
    holdSide: ctx.holdSide,
    cardId: ctx.cardId,
    category,
    lastError: repairResult.lastError ?? "",
    mark: repairResult.mark ?? 0,
    attempts: repair.attempts ?? [],
    closeImmediately: false,
    action,
  };
  const alertText = formatBitgetNakedPositionAlert(alertDetails);
  record.nakedPositionClosed = false;
  record.tpslVerifyDeferred = true;
  record.stopUnconfirmed = true;
  log.warn(
    `${alertText}（开仓请求已带止损；校验未确认，不平仓。BITGET_NAKED_POSITION_ACTION=${action}）`
  );
  return { ok: true, record, reason: "stop_unconfirmed_kept", deferred: true };
}
