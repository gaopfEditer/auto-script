/**
 * discord-collector 配置（环境变量覆盖）。
 */
import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildShowSidebarChannelGroups } from "./discord-show-channels.js";
import { loadDiscordGroupsFromFile } from "./discord-groups-file.js";
import { PANGMAO_OCR_YIELD_EMIT_BELOW_PCT } from "./discord-signal-ocr-parser.js";
import { parseKolvipChannelIdsEnv } from "./kolvip-cdp-config.js";
import { envTruthy, signalIngestSourceFromEnv } from "./signal-ingest-source.js";

const _repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const _collectorRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

/** @returns {{ channelIds: string[], namesByChannelId: Record<string, string>, source?: string }} */
function resolveDiscordShowSidebar() {
  const envShow = String(process.env.DISCORD_SHOW_CHANNEL_IDS ?? "").trim();
  if (envShow) {
    return { ...buildShowSidebarChannelGroups(envShow, process.env.DISCORD_GROUPS ?? ""), source: "env" };
  }
  const fromFile = loadDiscordGroupsFromFile();
  if (fromFile.showChannels.length) {
    return { ...fromFile.discordGroups, source: "discord_groups.json" };
  }
  return {
    ...buildShowSidebarChannelGroups("", process.env.DISCORD_GROUPS ?? ""),
    source: "discord-show-channels-default",
  };
}

/** @typedef {{ host: string; port: number; user: string; password: string; database: string }} MysqlConfig */

/** @type {MysqlConfig} */
export const mysql = {
  host: process.env.MYSQL_HOST ?? "127.0.0.1",
  port: Number(process.env.MYSQL_PORT ?? 3306),
  user: process.env.MYSQL_USER ?? "root",
  password: process.env.MYSQL_PASSWORD ?? "",
  database: process.env.MYSQL_DATABASE ?? "discord_collector",
};

function resolveCollectStartUrl() {
  const primary = (process.env.COLLECTOR_START_URL ?? "").trim();
  const blankish =
    !primary ||
    primary.toLowerCase() === "about:blank" ||
    primary.toLowerCase() === "about:blank/";
  const target = (process.env.TARGET_PAGE_URL ?? "").trim();
  if (blankish && target) {
    return { url: target, usedTargetFallback: true };
  }
  if (primary) {
    return { url: primary, usedTargetFallback: false };
  }
  return { url: "https://discord.com/login", usedTargetFallback: false };
}

/** @param {string} url */
function isDiscordChannelUrl(url) {
  return /discord\.com\/channels\/[^/?#]+\/[^/?#]+/i.test(String(url || "").trim());
}

/**
 * CDP 保活 / 断页恢复用的频道直链（须含 guild + channel）。
 * 未配置 START_URL 为频道时，默认打开 Show 同源 guild + 大镖客频道。
 */
function resolveCdpDiscordUrl(collectStartUrl) {
  const explicit = (process.env.COLLECTOR_DISCORD_RECOVERY_URL ?? "").trim();
  if (isDiscordChannelUrl(explicit)) return explicit;
  if (isDiscordChannelUrl(collectStartUrl)) return collectStartUrl.trim();
  const target = (process.env.TARGET_PAGE_URL ?? "").trim();
  if (isDiscordChannelUrl(target)) return target;
  const g = (
    process.env.COLLECTOR_DISCORD_DEFAULT_GUILD_ID ?? "1444959079209504831"
  ).trim();
  const c = (
    process.env.COLLECTOR_DISCORD_DEFAULT_CHANNEL_ID ?? "1444962339743989843"
  ).trim();
  if (g && c) {
    return `https://discord.com/channels/${encodeURIComponent(g)}/${encodeURIComponent(c)}`;
  }
  return collectStartUrl;
}

const collectStart = resolveCollectStartUrl();
const cdpDiscordUrl = resolveCdpDiscordUrl(collectStart.url);

function parseIdList(raw) {
  if (!raw?.trim()) return [];
  return [
    ...new Set(
      raw
        .replace(/\|/g, ",")
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean)
    ),
  ];
}

/**
 * Show 侧栏 `DISCORD_GROUPS`：`channelId:显示名` 逗号分隔（仅第一个 `:` 分割 id / 名）。
 * @returns {{ channelIds: string[], namesByChannelId: Record<string, string> }}
 */
export function parseDiscordGroups(raw) {
  /** @type {string[]} */
  const channelIds = [];
  /** @type {Record<string, string>} */
  const namesByChannelId = {};
  const seen = new Set();
  if (!raw?.trim()) return { channelIds, namesByChannelId };
  for (const part of raw.replace(/\|/g, ",").split(",")) {
    const seg = part.trim();
    if (!seg) continue;
    const colon = seg.indexOf(":");
    let id = "";
    let name = "";
    if (colon > 0) {
      id = seg.slice(0, colon).trim();
      name = seg.slice(colon + 1).trim();
    } else {
      id = seg;
    }
    if (!id || seen.has(id)) continue;
    seen.add(id);
    channelIds.push(id);
    if (name) namesByChannelId[id] = name;
  }
  return { channelIds, namesByChannelId };
}

/**
 * @template {{ channelId: string, guildId?: string, name?: string, [key: string]: unknown }} T
 * @param {T[]} channels
 * @param {string} [guildId]
 * @param {{ channelIds: string[], namesByChannelId: Record<string, string> }} [groups]
 * @returns {T[]}
 */
export function applyDiscordGroupsChannelList(channels, guildId = "", groups) {
  const { channelIds, namesByChannelId } =
    groups ?? parseDiscordGroups(process.env.DISCORD_GROUPS ?? "");
  if (!channelIds.length) return channels;
  const gid = String(guildId ?? "").trim();
  const byId = new Map(channels.map((c) => [String(c.channelId), c]));
  /** @type {T[]} */
  const out = [];
  for (const id of channelIds) {
    const envName = namesByChannelId[id];
    const row = byId.get(id);
    if (row) {
      out.push(envName ? { ...row, name: envName } : row);
      continue;
    }
    if (!gid) continue;
    out.push({
      channelId: id,
      guildId: gid,
      name: envName || `频道 ${id.slice(-6)}`,
      type: 0,
      lastMessagePreview: "",
      lastMessageAtMs: 0,
      updatedAt: null,
    });
  }
  return out;
}

/** @param {string | undefined} raw */
function parseCardKlineSources(raw) {
  const allowed = new Set(["binance", "bybit", "okx", "bitget", "gate"]);
  const list = String(raw ?? "binance,bybit,bitget,gate,okx")
    .split(/[,;\s]+/)
    .map((s) => s.trim().toLowerCase())
    .filter((s) => allowed.has(s));
  return list.length ? list : ["binance", "bybit", "bitget", "gate", "okx"];
}

/** @param {string[]} envKeys */
function envProxy(...envKeys) {
  for (const key of envKeys) {
    const v = (process.env[key] ?? "").trim();
    if (v) return v;
  }
  return "";
}

const commonProxy = envProxy("COMMON_PROXY");

export const config = {
  mysql,
  logLevel: process.env.LOG_LEVEL ?? "info",
  startUrl: collectStart.url,
  /** CDP 附加：保活刷新、断页恢复、轮询切频道时的默认 URL */
  cdpDiscordUrl,
  collectStartUsedTargetFallback: collectStart.usedTargetFallback,
  cdpConnectUrl: (process.env.CDP_CONNECT_URL ?? "").trim(),
  /**
   * CDP 附加后自动打开 startUrl（Discord 频道）并定时刷新保活。
   * 默认开；COLLECTOR_CDP_AUTO_GOTO=0 关闭。
   */
  cdpAutoGoto: !["0", "false", "no", "off"].includes(
    String(process.env.COLLECTOR_CDP_AUTO_GOTO ?? "1").toLowerCase()
  ),
  /**
   * CDP 注入脚本：伪造页面始终前台，减轻 Discord 后台节流 Gateway。
   * 默认开；COLLECTOR_CDP_VISIBILITY_KEEPALIVE=0 关闭。
   */
  cdpVisibilityKeepalive: !["0", "false", "no", "off"].includes(
    String(process.env.COLLECTOR_CDP_VISIBILITY_KEEPALIVE ?? "1").toLowerCase()
  ),
  /**
   * CDP 保活/切频道/翻页：不激活 Chrome 标签（静默刷新、后台新开标签）。
   * 默认开；COLLECTOR_CDP_SILENT_NAV=0 恢复 bringToFront + Playwright reload。
   */
  cdpSilentNavigation: !["0", "false", "no", "off"].includes(
    String(process.env.COLLECTOR_CDP_SILENT_NAV ?? "1").toLowerCase()
  ),
  /**
   * 定时用 CDP 轮询打开信号频道（每次只切 1 个，避免连跳）。
   * 默认开；COLLECTOR_CDP_CHANNEL_ROTATE=0 关闭。
   * 间隔默认 15 分钟切下一个（勿依赖前端点频道触发）。
   */
  cdpChannelRotate: !["0", "false", "no", "off"].includes(
    String(process.env.COLLECTOR_CDP_CHANNEL_ROTATE ?? "1").toLowerCase()
  ),
  cdpChannelRotateIntervalMs: Math.max(
    60_000,
    Number(process.env.COLLECTOR_CDP_CHANNEL_ROTATE_INTERVAL_MS) || 900_000
  ),
  /** Show 页从 MySQL 批量拉取各频道近 N 天消息（无需先 CDP 点进频道） */
  /** Show WS：discord_message_batch 合并推送间隔（毫秒），减轻消息列表抖动 */
  uiMessageBroadcastDebounceMs: Math.max(
    200,
    Number(process.env.COLLECTOR_UI_MESSAGE_DEBOUNCE_MS) || 3000
  ),
  discordShowSnapshotDays: Math.min(
    14,
    Math.max(1, Number(process.env.DISCORD_SHOW_SNAPSHOT_DAYS) || 7)
  ),
  /** 巨鲸卡片拉取 /eval / Show 补拉窗口（与 kolvip-sig 30 天榜对齐） */
  kolvipCardIngestDays: Math.min(
    90,
    Math.max(7, Number(process.env.KOLVIP_CARD_INGEST_DAYS ?? 30) || 30)
  ),
  kolvipShowSnapshotDays: Math.min(
    90,
    Math.max(
      7,
      Number(
        process.env.KOLVIP_SHOW_SNAPSHOT_DAYS ??
          process.env.KOLVIP_CARD_INGEST_DAYS ??
          30
      ) || 30
    )
  ),
  kolvipEvalDefaultDays: Math.min(
    90,
    Math.max(1, Number(process.env.KOLVIP_EVAL_DEFAULT_DAYS ?? 30) || 30)
  ),
  /** kolvip 向上翻页补历史：缓存已覆盖锚点且在 TTL 内只读 MySQL；**不**用于 live 尾拉/榜单轮转 */
  kolvipShowCatchupTtlMs: (() => {
    const hours = Number(process.env.KOLVIP_SHOW_CATCHUP_TTL_HOURS);
    if (Number.isFinite(hours) && hours > 0) {
      return Math.max(300_000, hours * 3_600_000);
    }
    const days = Math.min(90, Math.max(1, Number(process.env.KOLVIP_SHOW_SNAPSHOT_DAYS)));
    const fallback = Math.min(
      90,
      Math.max(
        7,
        Number(
          process.env.KOLVIP_CARD_INGEST_DAYS ??
            process.env.KOLVIP_SHOW_SNAPSHOT_DAYS ??
            30
        ) || 30
      )
    );
    const windowDays = Number.isFinite(days) && days > 0 ? days : fallback;
    return Math.max(300_000, windowDays * 24 * 3_600_000);
  })(),
  discordShowSnapshotPerChannel: Math.min(
    300,
    Math.max(20, Number(process.env.DISCORD_SHOW_SNAPSHOT_PER_CHANNEL) || 120)
  ),
  /** Show 频道历史 CDP 预热有效时长（多前端共享库内标记，期内不重复上滚） */
  discordShowHistoryWarmTtlMs: Math.max(
    3_600_000,
    Number(process.env.DISCORD_SHOW_HISTORY_WARM_TTL_HOURS || 12) * 3_600_000
  ),
  /** 服务端单次预热最多 CDP 上滚页数 */
  discordShowHistoryWarmPages: Math.min(
    8,
    Math.max(1, Number(process.env.DISCORD_SHOW_HISTORY_WARM_PAGES) || 4)
  ),
  /** @deprecated 已改为每次只切 1 频道，dwell 不再使用；保留以免旧配置报错 */
  cdpChannelRotateDwellMs: Math.max(
    3_000,
    Number(process.env.COLLECTOR_CDP_CHANNEL_ROTATE_DWELL_MS) || 12_000
  ),
  /** CDP 断连 Telegram 提醒（需信号 TG 已配置），默认开 */
  cdpTelegramNotifyDisconnect: !["0", "false", "no", "off"].includes(
    String(process.env.COLLECTOR_CDP_TELEGRAM_DISCONNECT ?? "1").toLowerCase()
  ),
  /** CDP 首次连接 / 重连成功 Telegram 提醒，默认开 */
  cdpTelegramNotifyConnect: !["0", "false", "no", "off"].includes(
    String(process.env.COLLECTOR_CDP_TELEGRAM_CONNECT ?? "1").toLowerCase()
  ),
  /** CDP 断连持续超过该毫秒且仍未恢复才推 Telegram（默认 15 分钟） */
  cdpTelegramDisconnectAfterMs: Math.max(
    60_000,
    Number(process.env.COLLECTOR_CDP_TELEGRAM_DISCONNECT_AFTER_MS) || 15 * 60_000,
  ),
  /**
   * Discord 页定时刷新间隔（ms）。0=不刷新。
   * 未配置且 startUrl 为 /channels/… 时默认 5 分钟，避免 Gateway 假死。
   */
  pageReloadIntervalMs: (() => {
    const raw = process.env.COLLECTOR_PAGE_RELOAD_INTERVAL_MS;
    if (raw != null && String(raw).trim() !== "") {
      return Math.max(0, Number(raw) || 0);
    }
    if (/discord\.com\/channels\//i.test(collectStart.url)) return 5 * 60_000;
    return 0;
  })(),
  collectNetworkTrace: ["1", "true", "yes", "on"].includes(
    String(process.env.COLLECTOR_NETWORK_TRACE ?? "0").toLowerCase()
  ),
  collectWsFrameTrace: ["1", "true", "yes", "on"].includes(
    String(process.env.COLLECTOR_WS_FRAME_TRACE ?? "0").toLowerCase()
  ),
  /** 打印 Gateway MESSAGE_CREATE 等实时消息行（默认关，避免群聊刷屏） */
  gatewayMessageLog: ["1", "true", "yes", "on"].includes(
    String(process.env.DISCORD_GATEWAY_MESSAGE_LOG ?? "0").toLowerCase()
  ),
  /** Webhook 转发逐条日志（POST / 已转发等，默认关） */
  webhookForwardLog: ["1", "true", "yes", "on"].includes(
    String(process.env.DISCORD_WEBHOOK_FORWARD_LOG ?? "0").toLowerCase()
  ),
  /** 卡片价格校验 / 回测 / 接近检查逐条日志（默认关） */
  cardPullForwardLog: ["1", "true", "yes", "on"].includes(
    String(process.env.DISCORD_CARDPULL_FORWARD_LOG ?? "0").toLowerCase()
  ),
  /** 新卡片桌面通知（浏览器 Notification API，默认关） */
  cardToastDesktop: ["1", "true", "yes", "on"].includes(
    String(process.env.CARD_TOAST_DESKTOP ?? "0").toLowerCase()
  ),
  /** 新卡片 Toast 位置：bottom-right | top-right */
  cardToastPosition:
    String(process.env.CARD_TOAST_POSITION ?? "bottom-right").toLowerCase() === "top-right"
      ? "top-right"
      : "bottom-right",
  collectUiPort: Number(process.env.COLLECTOR_UI_PORT ?? 3851),
  requiredTopLevelKeys: (process.env.COLLECTOR_REQUIRED_KEYS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),
  /** 非空时仅入库/展示这些 guild 的消息 */
  monitoredGuildIds: parseIdList(process.env.DISCORD_MONITORED_GUILD_IDS ?? ""),
  /** Show /show 左侧频道白名单（DISCORD_SHOW_CHANNEL_IDS → data/discord_groups.json showChannels → 内置默认） */
  discordShowSidebar: resolveDiscordShowSidebar(),
  /** 旧 Show 白名单 env（未设 DISCORD_SHOW_CHANNEL_IDS 时仍可读 DISCORD_GROUPS） */
  discordGroups: parseDiscordGroups(process.env.DISCORD_GROUPS ?? ""),
  /** 信号卡片监听频道（默认内置 4 个） */
  discordSignalChannelIds: parseIdList(process.env.DISCORD_SIGNAL_CHANNEL_IDS ?? ""),
  /** 附件图片 OCR 信号频道（空=默认仅胖猫社区） */
  discordSignalOcrChannelIds: parseIdList(process.env.DISCORD_SIGNAL_OCR_CHANNEL_IDS ?? ""),
  /** 本机 OCR 服务根 URL */
  discordSignalOcrBaseUrl: (process.env.DISCORD_SIGNAL_OCR_BASE_URL ?? "http://127.0.0.1:8866")
    .trim()
    .replace(/\/$/, ""),
  /** 胖猫单图 OCR：收益率 ≥ 该值且非负则不出卡（默认 40；负数始终出卡） */
  discordSignalOcrOpenMaxProfitPct: Number(
    process.env.DISCORD_SIGNAL_OCR_OPEN_MAX_PROFIT_PCT ?? PANGMAO_OCR_YIELD_EMIT_BELOW_PCT,
  ),
  /** OCR 开仓指纹去重窗口（毫秒，默认 5 分钟） */
  discordSignalOcrDedupWindowMs: Math.max(
    60_000,
    Number(process.env.DISCORD_SIGNAL_OCR_DEDUP_WINDOW_MS ?? 5 * 60_000),
  ),
  discordSignalOcrTimeoutMs: Math.max(
    5_000,
    Number(process.env.DISCORD_SIGNAL_OCR_TIMEOUT_MS ?? 30_000),
  ),
  /**
   * 胖猫卡片优先队列（msg-relay-service）。两者都空则跳过入队。
   * 不要在仓库里写真实 secret。
   */
  priorityQueueBaseUrl: (process.env.PRIORITY_QUEUE_BASE_URL ?? "").trim().replace(/\/$/, ""),
  priorityQueueSecret: (process.env.PRIORITY_QUEUE_SECRET ?? "").trim(),
  priorityQueueTimeoutMs: Math.max(
    1_000,
    Number(process.env.PRIORITY_QUEUE_TIMEOUT_MS ?? 8_000),
  ),
  /** Telegram 推送频道（空=内置 8 个） */
  discordTelegramPushChannelIds: parseIdList(process.env.DISCORD_TELEGRAM_PUSH_CHANNEL_IDS ?? ""),
  /** 实时推送频道，不参与 debounce（空=无，全部走 2 分钟聚合） */
  discordTelegramRealtimeChannelIds: parseIdList(process.env.DISCORD_TELEGRAM_REALTIME_CHANNEL_IDS ?? ""),
  /** 非实时频道：最后一条消息后等待毫秒再批量转发（默认 120000） */
  telegramPushDebounceMs: Number(process.env.DISCORD_TELEGRAM_PUSH_DEBOUNCE_MS ?? 120),
  /** Gateway 消息：先转发 Telegram/Webhook，再入库（默认开启，省 20–150ms+） */
  telegramPriorityForward: !["0", "false", "no", "off"].includes(
    String(process.env.DISCORD_TELEGRAM_PRIORITY_FORWARD ?? "1").toLowerCase()
  ),
  ollamaGenerateUrl: (process.env.OLLAMA_GENERATE_URL ?? "http://127.0.0.1:11434/api/generate").trim(),
  ollamaModel: (process.env.OLLAMA_MODEL ?? "gemma4:26b").trim(),
  ollamaGenerateTimeoutMs: Number(process.env.OLLAMA_GENERATE_TIMEOUT_MS ?? 60_000),
  ollamaEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.OLLAMA_ENABLED ?? "1").toLowerCase()
  ),
  /** 回溯/批量 ingest 是否在规则解析失败后调 Ollama（默认关，避免 ~60s/条） */
  ollamaBackfillEnabled: ["1", "true", "yes", "on"].includes(
    String(process.env.OLLAMA_BACKFILL_ENABLED ?? "0").toLowerCase()
  ),
  telegramSendUrl: (process.env.TELEGRAM_SEND_URL ?? "http://127.0.0.1:8000/api/telegram/send").trim(),
  /** HTTP 网关失败时兜底（与 oi_mornitor notify_telegram 同源 env） */
  telegramBotToken: (process.env.TELEGRAM_BOT_TOKEN ?? "").trim(),
  telegramPushChatId: (() => {
    const v = String(process.env.TELEGRAM_PUSH_CHAT_ID ?? "").trim();
    if (!v) return "";
    const n = Number(v);
    return Number.isFinite(n) ? n : v;
  })(),
  /** 主群卡片通知（listen 建卡 / OI MAIN 推送）；与 TELEGRAM_PUSH_CHAT_ID 一致时 digest 口径对齐 */
  mainCardTelegramChatId: (() => {
    const v = String(process.env.MAIN_CARD_TELEGRAM_CHAT_ID ?? "").trim();
    if (!v) return "";
    const n = Number(v);
    return Number.isFinite(n) ? n : v;
  })(),
  /** kolvip Show 胜率榜前 10 频道信号卡片 → 独立 TG 群 */
  kolvipTop10TelegramChatId: (() => {
    const v = String(
      process.env.KOLVIP_TOP10_TELEGRAM_CHAT_ID ?? process.env.KOLVIP_TOP5_TELEGRAM_CHAT_ID ?? "",
    ).trim();
    if (!v) return "";
    const n = Number(v);
    return Number.isFinite(n) ? n : v;
  })(),
  kolvipTop10TelegramChannelIds: parseIdList(
    process.env.KOLVIP_TOP10_TELEGRAM_CHANNEL_IDS ??
      process.env.KOLVIP_TOP5_TELEGRAM_CHANNEL_IDS ??
      "",
  ),
  /** Show 前 N 频道 · 按发单顺序筛单 → operate CDP（四行 + 优化入场） */
  kolvipOperateCdpEnabled: ["1", "true", "yes", "on"].includes(
    String(process.env.KOLVIP_OPERATE_CDP_ENABLED ?? "0").toLowerCase(),
  ),
  kolvipOperateCdpTopChannels: Math.max(
    1,
    Number(process.env.KOLVIP_OPERATE_CDP_TOP_CHANNELS ?? 5) || 5,
  ),
  kolvipOperateCdpChannelIds: parseIdList(process.env.KOLVIP_OPERATE_CDP_CHANNEL_IDS ?? ""),
  /**
   * 全局发单顺序槽位：仅 `999` = 全部；`1,3,5,6` = 只取这些序号（08:00 复位）
   */
  kolvipOperateCdpOrderSlots: (() => {
    const raw = process.env.KOLVIP_OPERATE_CDP_ORDER_SLOTS ?? "1,3,5,6";
    return raw
      .split(/[,;\s]+/)
      .map((x) => Number(String(x).trim()))
      .filter((n) => Number.isFinite(n) && n > 0);
  })(),
  /** 列表复位时刻（Asia/Shanghai，默认 8 点） */
  kolvipOperateCdpResetHour: Math.max(
    0,
    Math.min(23, Number(process.env.KOLVIP_OPERATE_CDP_RESET_HOUR ?? 8) || 8),
  ),
  kolvipEvalChannelIds: parseIdList(process.env.KOLVIP_EVAL_CHANNEL_IDS ?? ""),
  telegramSendTimeoutMs: Number(process.env.TELEGRAM_SEND_TIMEOUT_MS ?? 15_000),
  /** 默认 true：全量 WS/API 日志与 UI；设 DISCORD_DEBUG_MODE=0 为精简模式 */
  debugMode: ["0", "false", "no", "off"].includes(
    String(process.env.DISCORD_DEBUG_MODE ?? "1").toLowerCase()
  )
    ? false
    : true,
  /** 默认关：勿把每条 Gateway WS 帧写入 MySQL frames（曾膨胀至 100GB+） */
  framePersist: ["1", "true", "yes", "on"].includes(
    String(process.env.COLLECTOR_FRAME_PERSIST ?? "0").toLowerCase()
  ),
  /** youtube-fetch 本地归档目录（前端文稿预览） */
  youtubeArchivesDir: (process.env.YOUTUBE_ARCHIVES_DIR ?? "").trim()
    ? path.resolve(process.env.YOUTUBE_ARCHIVES_DIR.trim())
    : path.join(_repoRoot, "youtube-fetch", "archives"),
  /** youtube-fetch HTTP API（队列拉取） */
  youtubeFetchUrl: (process.env.YOUTUBE_FETCH_URL ?? "http://127.0.0.1:3920").trim(),
  /** WhisprRT 等目录：启动后延时扫描 *.txt 并解析（第一行标题） */
  pasteParseInputDir: (process.env.PASTE_PARSE_INPUT_DIR ?? "").trim()
    ? path.resolve(process.env.PASTE_PARSE_INPUT_DIR.trim())
    : path.resolve(_repoRoot, "..", "WhisprRT", "output"),
  /** 文稿解析结果 JSON 目录（与源 txt 同名 .json，已存在则跳过） */
  pasteParseOutputDir: (process.env.PASTE_PARSE_OUTPUT_DIR ?? "").trim()
    ? path.resolve(process.env.PASTE_PARSE_OUTPUT_DIR.trim())
    : path.join(_collectorRoot, "data", "paste-parse"),
  pasteParseStartupDelayMs: Number(process.env.PASTE_PARSE_STARTUP_DELAY_MS ?? 15_000),
  /** 输入目录轮询间隔：探测新 .txt 并自动解析（默认 10 分钟） */
  pasteParseWatchIntervalMs: Number(process.env.PASTE_PARSE_WATCH_INTERVAL_MS ?? 600_000),
  /** 统一卡片开放 API Key（Header: X-Cards-Api-Key 或 Bearer）；未设 env 时用下方默认 */
  cardsApiKey: (process.env.CARDS_API_KEY ?? "Gpf123456").trim(),
  /**
   * POST /api/v1/cards 等归档时：若 channelId 为已知 Discord 频道，写入该频道时间线一条最新消息。
   * 默认开；CARD_API_INJECT_CHANNEL_MESSAGE=0 关闭。
   */
  cardApiInjectChannelMessage: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_API_INJECT_CHANNEL_MESSAGE ?? "1").toLowerCase()
  ),
  /** 统一 HTTP(S) 代理（Bitget / WEEX / Webhook / 币安等默认共用） */
  commonProxy,
  /** 币安行情（卡片价格校验 / 接近推送） */
  binanceFapiUrl: (process.env.BINANCE_FAPI_URL ?? "https://fapi.binance.com").trim(),
  binanceRequestTimeoutMs: Number(process.env.BINANCE_REQUEST_TIMEOUT_MS ?? 15_000),
  /** 币安 API 代理（国内直连常失败；默认 COMMON_PROXY） */
  binanceProxy: envProxy("BINANCE_PROXY", "COMMON_PROXY", "DISCORD_WEBHOOK_PROXY", "HTTPS_PROXY", "HTTP_PROXY"),
  /** Binance Alpha（bapi）源站；回测合约找不到或 0x 地址时走 Alpha */
  binanceAlphaBaseUrl: (process.env.BINANCE_ALPHA_BASE_URL ?? "https://www.binance.com").trim(),
  binanceAlphaTokenListTtlMs: Number(process.env.BINANCE_ALPHA_TOKEN_LIST_TTL_MS ?? 600_000),
  /** 清算/回溯 K 线来源顺序（binance,bybit,okx）；451/418 等会自动试下一源 */
  cardKlineSources: parseCardKlineSources(process.env.CARD_KLINE_SOURCES),
  /** 回溯 batch 回测 K 线顺序（默认同 cardKlineSources；可单独 TELEGRAM_BACKFILL_KLINE_SOURCES） */
  telegramBackfillKlineSources: parseCardKlineSources(
    process.env.TELEGRAM_BACKFILL_KLINE_SOURCES || process.env.CARD_KLINE_SOURCES,
  ),
  /** 两次 K 线 HTTP 请求最小间隔（批量回溯防 429，默认 150ms） */
  cardKlineMinIntervalMs: Number(process.env.CARD_KLINE_MIN_INTERVAL_MS ?? 150),
  /** K 线 HTTP 429/限速时最多重试次数 */
  cardKlineFetchMaxAttempts: Number(process.env.CARD_KLINE_FETCH_MAX_ATTEMPTS ?? 3),
  /** Telegram/Discord 回溯 batch 回测：每张卡之间的间隔（数据量大时防 429，默认 450ms） */
  telegramBackfillBacktestDelayMs: Number(process.env.TELEGRAM_BACKFILL_BACKTEST_DELAY_MS ?? 450),
  /** 同 symbol+方向+阶段，该时间窗内只保留最早信号（默认 20 分钟） */
  telegramBackfillDedupWindowMs: Number(process.env.TELEGRAM_BACKFILL_DEDUP_WINDOW_MS ?? 20 * 60 * 1000),
  /** 回溯 batch 盈亏绝对值超过则视为异常（默认 600%，约 20x×30% 波动） */
  telegramBackfillMaxAbsPnlPct: Number(process.env.TELEGRAM_BACKFILL_MAX_ABS_PNL_PCT ?? 600),
  /** 入场价与信号市价倍数超过则视为 K 线/币种错配 */
  telegramBackfillMaxEntryMarketRatio: Number(process.env.TELEGRAM_BACKFILL_MAX_ENTRY_MARKET_RATIO ?? 3),
  /** 回溯 batch 回测：K 线多轮自适应（换所顺序 + 保守合约名 + 退避） */
  telegramBackfillKlineAdaptive: !["0", "false", "no", "off"].includes(
    String(process.env.TELEGRAM_BACKFILL_KLINE_ADAPTIVE ?? "1").toLowerCase(),
  ),
  cardPriceMonitorIntervalMs: Number(process.env.CARD_PRICE_MONITOR_INTERVAL_MS ?? 300_000),
  /** 加密接近推送：每 5min 检查，距入场 ±5% */
  cardProximityCryptoCheckMs: Number(process.env.CARD_PROXIMITY_CRYPTO_CHECK_MS ?? 300_000),
  cardProximityCryptoBandPct: Number(process.env.CARD_PROXIMITY_CRYPTO_BAND_PCT ?? 5.0),
  /** 是否启用 TP1/2/3 自动评价（默认开） */
  cardAutoEvalEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_AUTO_EVAL_ENABLED ?? "1").toLowerCase()
  ),
  /** 档位进度状态机：每小时检查入场/TP/SL（1/N 分批） */
  cardLevelCheckEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_LEVEL_CHECK_ENABLED ?? "1").toLowerCase()
  ),
  cardLevelCheckMs: Number(process.env.CARD_LEVEL_CHECK_MS ?? 3_600_000),
  /** 超过该时长未完结的卡片视为失效，不再拉 K 线兜底核验（默认 16h，与评估待结算窗口对齐） */
  cardKlineVerifyMaxAgeMs: Number(process.env.CARD_KLINE_VERIFY_MAX_AGE_MS ?? 16 * 3_600_000),
  /** 已入场仍未决：超过该窗口按末价强制结算（默认 16h） */
  cardEvalPendingMaxAgeMs: Number(
    process.env.CARD_EVAL_PENDING_MAX_AGE_MS ??
      (Number(process.env.CARD_EVAL_PENDING_MAX_HOURS ?? 16) || 16) * 3_600_000
  ),
  /** 待结算批量检查间隔（默认 4h） */
  cardEvalPendingSettleIntervalMs: Number(
    process.env.CARD_EVAL_PENDING_SETTLE_INTERVAL_MS ?? 4 * 3_600_000
  ),
  cardEvalPendingSettleEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_EVAL_PENDING_SETTLE_ENABLED ?? "1").toLowerCase()
  ),
  /** 强制结算扫：计划入场价与现价相差 ≤ 该 % 则按现价视为已入场（默认 2） */
  cardEvalNearMarketEntryPct: Number(process.env.CARD_EVAL_NEAR_MARKET_ENTRY_PCT ?? 2),
  /**
   * 卡片挂 Bitget/WEEX 单后：TP1 触达则把止损移到开仓价（默认开，每 30s 扫一次）。
   */
  cardTp1BreakevenEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_TP1_BREAKEVEN_ENABLED ?? "1").toLowerCase()
  ),
  cardTp1BreakevenIntervalMs: Number(process.env.CARD_TP1_BREAKEVEN_INTERVAL_MS ?? 30_000),
  /** 股票接近推送：每 1 天检查，剩余落差 ≤ 10%（100→110 则在 109–110 提醒） */
  cardProximityStockCheckMs: Number(process.env.CARD_PROXIMITY_STOCK_CHECK_MS ?? 86_400_000),
  cardProximityStockGapPct: Number(process.env.CARD_PROXIMITY_STOCK_GAP_PCT ?? 0.1),
  cardProximityTelegram: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_PROXIMITY_TELEGRAM ?? "0").toLowerCase()
  ),
  /** 价格涨跌幅达阶梯提醒上移止损（默认 5/10/15/20%，不含杠杆） */
  cardProfitTrailEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_PROFIT_TRAIL_ENABLED ?? "1").toLowerCase()
  ),
  cardProfitTrailTelegram: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_PROFIT_TRAIL_TELEGRAM ?? "1").toLowerCase()
  ),
  cardProfitTrailLevels: String(process.env.CARD_PROFIT_TRAIL_LEVELS ?? "5,10,15,20").trim(),
  /** 同卡两次盈利阶梯提醒最短间隔（毫秒，默认 1h） */
  cardProfitTrailCooldownMs: Math.max(
    60_000,
    Number(process.env.CARD_PROFIT_TRAIL_COOLDOWN_MS ?? 3_600_000) || 3_600_000
  ),
  /** 价格校验：加密默认 1 天（Binance K 线）；legacy 3h；股票较长周期 */
  cardVerifyCryptoWindowDays: Number(process.env.CARD_VERIFY_CRYPTO_WINDOW_DAYS ?? 1),
  cardVerifyDefaultWindowHours: Number(process.env.CARD_VERIFY_DEFAULT_HOURS ?? 3),
  cardVerifyStockWindowDays: Number(process.env.CARD_VERIFY_STOCK_WINDOW_DAYS ?? 30),
  /** 自动校验盈亏按杠杆倍数（默认 100x） */
  cardVerifyLeverage: Number(process.env.CARD_VERIFY_LEVERAGE ?? 100),
  /** 卡片批量回溯：每 N 小时标记一次盈亏（默认 12h）；K 线拉取最长 N 天（默认 365），不因天数截止任务 */
  cardBatchBacktestEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_BATCH_BACKTEST_ENABLED ?? "1").toLowerCase()
  ),
  cardBacktestSliceHours: Number(process.env.CARD_BACKTEST_SLICE_HOURS ?? 12),
  cardBacktestMaxDays: Number(process.env.CARD_BACKTEST_MAX_DAYS ?? 365),
  /** 评价表单：主流 BTC/ETH 默认杠杆 */
  cardEvalMajorLeverage: Number(process.env.CARD_EVAL_MAJOR_LEVERAGE ?? 100),
  /** 评价表单：山寨默认杠杆 */
  cardEvalAltcoinLeverage: Number(process.env.CARD_EVAL_ALTCOIN_LEVERAGE ?? 20),
  /** 统计/清算：黄金 XAU 等 */
  cardStatsLeverageGold: Number(process.env.CARD_STATS_LEVERAGE_GOLD ?? 50),
  /** 统计/清算：BTC/ETH */
  cardStatsLeverageMajor: Number(process.env.CARD_STATS_LEVERAGE_MAJOR ?? 100),
  /** 统计/清算：其余币种 */
  cardStatsLeverageAltcoin: Number(process.env.CARD_STATS_LEVERAGE_ALTCOIN ?? 20),
  /** 卡片外送（外部评估服务）：默认开，WS 优先、HTTP 回退 */
  cardSinkEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.CARD_SINK_ENABLED ?? "1").toLowerCase()
  ),
  cardSinkWsUrl: (process.env.CARD_SINK_WS_URL ?? "ws://127.0.0.1:8765/ws/cards").trim(),
  cardSinkHttpUrl: (process.env.CARD_SINK_HTTP_URL ?? "http://127.0.0.1:8765/api/cards").trim(),
  cardSinkTimeoutMs: Number(process.env.CARD_SINK_TIMEOUT_MS ?? 8_000),
  cardSinkReconnectMs: Number(process.env.CARD_SINK_RECONNECT_MS ?? 3_000),
  /** OI Monitor（同仓 oi_mornitor）：健康检查与 UI 嵌入地址 */
  oiWebBaseUrl: (process.env.OI_WEB_BASE_URL ?? "http://127.0.0.1:8765").replace(/\/$/, ""),
  /** iframe 优先地址；空则用 oiWebBaseUrl。oi:dev 时可设 http://127.0.0.1:5173 */
  /** 本机 iframe 覆盖（如 oi:dev :5173）；勿用 VITE_*，避免与 Vue dev 端口混淆 */
  oiEmbedUrl: (process.env.OI_EMBED_URL ?? "").replace(/\/$/, ""),
  /**
   * 浏览器侧公网嵌入地址（前端上云时必填）。
   * 本地探测仍用 oiWebBaseUrl；iframe 优先用本字段，避免把 127.0.0.1 塞给访客浏览器。
   */
  oiPublicEmbedUrl: (
    process.env.OI_PUBLIC_EMBED_URL ??
    process.env.VITE_OI_PUBLIC_EMBED_URL ??
    ""
  ).replace(/\/$/, ""),
  oiHealthTimeoutMs: Number(process.env.OI_HEALTH_TIMEOUT_MS ?? 3_000),
  /** collect:ui 启动时自动拉起并守护 oi_mornitor（默认开） */
  oiAutoStart: !["0", "false", "no", "off"].includes(
    String(process.env.OI_AUTO_START ?? "1").toLowerCase()
  ),
  oiSupervisorIntervalMs: Number(process.env.OI_SUPERVISOR_INTERVAL_MS ?? 15_000),
  /** collect:ui 启动时重启已在线的本仓库 oi（默认开，便于代码更新生效） */
  oiRestartWithUi: !["0", "false", "no", "off"].includes(
    String(process.env.OI_RESTART_WITH_UI ?? "1").toLowerCase()
  ),
  /** 平台热点（news_mornitor / CryptoPulse） */
  newsWebBaseUrl: (process.env.NEWS_WEB_BASE_URL ?? "http://127.0.0.1:8770").replace(/\/$/, ""),
  newsEmbedUrl: (process.env.NEWS_EMBED_URL ?? process.env.VITE_NEWS_EMBED_URL ?? "").replace(
    /\/$/,
    "",
  ),
  newsPublicEmbedUrl: (
    process.env.NEWS_PUBLIC_EMBED_URL ??
    process.env.VITE_NEWS_PUBLIC_EMBED_URL ??
    ""
  ).replace(/\/$/, ""),
  newsHealthTimeoutMs: Number(process.env.NEWS_HEALTH_TIMEOUT_MS ?? 3_000),
  newsAutoStart: !["0", "false", "no", "off"].includes(
    String(process.env.NEWS_AUTO_START ?? "1").toLowerCase()
  ),
  newsSupervisorIntervalMs: Number(process.env.NEWS_SUPERVISOR_INTERVAL_MS ?? 20_000),
  /** 图文内容板（Python SQLite content_board） */
  contentBoardBaseUrl: (process.env.CONTENT_BOARD_BASE_URL ?? "http://127.0.0.1:8767").replace(
    /\/$/,
    ""
  ),
  contentBoardAutoStart: !["0", "false", "no", "off"].includes(
    String(process.env.CONTENT_BOARD_AUTO_START ?? "1").toLowerCase()
  ),
  contentBoardSupervisorIntervalMs: Number(
    process.env.CONTENT_BOARD_SUPERVISOR_INTERVAL_MS ?? 20_000
  ),
  /** 源频道 → Webhook 转发映射 JSON（见 config/channel-webhook-forwards.json） */
  webhookForwardsFile: (process.env.DISCORD_WEBHOOK_FORWARDS_FILE ?? "").trim()
    ? path.resolve(process.env.DISCORD_WEBHOOK_FORWARDS_FILE.trim())
    : path.join(_collectorRoot, "config", "channel-webhook-forwards.json"),
  webhookForwardTimeoutMs: Number(process.env.DISCORD_WEBHOOK_FORWARD_TIMEOUT_MS ?? 15_000),
  /** Node 发 Discord Webhook 用的 HTTP(S) 代理，需与 Chrome 一致，如 http://127.0.0.1:7890 */
  webhookForwardProxy: envProxy("DISCORD_WEBHOOK_PROXY", "COMMON_PROXY", "HTTPS_PROXY", "HTTP_PROXY"),
  /** Bitget 合约自动下单（密钥仅来自环境变量） */
  bitgetEnabled: !["0", "false", "no", "off"].includes(String(process.env.BITGET_ENABLED ?? "0").toLowerCase()),
  bitgetDryRun: !["0", "false", "no", "off"].includes(String(process.env.BITGET_DRY_RUN ?? "1").toLowerCase()),
  bitgetApiKey: (process.env.BITGET_API_KEY ?? "").trim(),
  bitgetApiSecret: (process.env.BITGET_API_SECRET ?? "").trim(),
  bitgetPassphrase: (process.env.BITGET_PASSPHRASE ?? "").trim(),
  bitgetBaseUrl: (process.env.BITGET_BASE_URL ?? "https://api.bitget.com").trim(),
  bitgetRequestTimeoutMs: Number(process.env.BITGET_REQUEST_TIMEOUT_MS ?? 15_000),
  /** Bitget API 代理（国内直连常失败；默认 COMMON_PROXY） */
  bitgetProxy: envProxy("BITGET_PROXY", "COMMON_PROXY", "DISCORD_WEBHOOK_PROXY", "HTTPS_PROXY", "HTTP_PROXY"),
  /**
   * Discord 雪花频道白名单。非空时仅这些频道走环境变量/JSON 策略。
   * Telegram 群（`-100…`）不看此列表，只看 channel_profiles.json 的 placeAnOrder。
   */
  bitgetAutoTradeChannelIds: parseIdList(process.env.BITGET_AUTO_TRADE_CHANNEL_IDS ?? ""),
  bitgetDefaultLeverage: Number(process.env.BITGET_DEFAULT_LEVERAGE ?? 20),
  bitgetGoldLeverage: Number(process.env.BITGET_GOLD_LEVERAGE ?? 50),
  bitgetOrderSizeUsdt: Number(process.env.BITGET_ORDER_SIZE_USDT ?? 1),
  bitgetMajorLeverage: Number(process.env.BITGET_MAJOR_LEVERAGE ?? 20),
  bitgetAltcoinLeverage: Number(process.env.BITGET_ALTCOIN_LEVERAGE ?? 20),
  bitgetInitialSlPct: Number(process.env.BITGET_INITIAL_SL_PCT ?? 5),
  bitgetTradeConfigFile: (process.env.BITGET_TRADE_CONFIG_FILE ?? "").trim()
    ? path.resolve(process.env.BITGET_TRADE_CONFIG_FILE.trim())
    : path.join(_collectorRoot, "config", "bitget-trade-channels.json"),
  /** WEEX 合约自动下单（交易参数默认与 Bitget 共用 BITGET_*） */
  weexEnabled: !["0", "false", "no", "off"].includes(String(process.env.WEEX_ENABLED ?? "0").toLowerCase()),
  weexDryRun: !["0", "false", "no", "off"].includes(
    String(process.env.WEEX_DRY_RUN ?? process.env.BITGET_DRY_RUN ?? "1").toLowerCase()
  ),
  weexApiKey: (process.env.WEEX_API_KEY ?? "").trim(),
  weexApiSecret: (process.env.WEEX_API_SECRET ?? "").trim(),
  weexPassphrase: (process.env.WEEX_PASSPHRASE ?? "").trim(),
  weexBaseUrl: (process.env.WEEX_BASE_URL ?? "https://api-contract.weex.com").trim(),
  weexRequestTimeoutMs: Number(process.env.WEEX_REQUEST_TIMEOUT_MS ?? process.env.BITGET_REQUEST_TIMEOUT_MS ?? 15_000),
  weexProxy: envProxy("WEEX_PROXY", "COMMON_PROXY", "BITGET_PROXY", "DISCORD_WEBHOOK_PROXY", "HTTPS_PROXY", "HTTP_PROXY"),
  /** Discord 频道白名单；留空则回退 BITGET_AUTO_TRADE_CHANNEL_IDS。不作用于 Telegram 群。 */
  weexAutoTradeChannelIds: parseIdList(
    process.env.WEEX_AUTO_TRADE_CHANNEL_IDS ?? process.env.BITGET_AUTO_TRADE_CHANNEL_IDS ?? ""
  ),
  /** 社区数据走本地 SQLite（默认开；与 MySQL 社区表独立） */
  communityUseSqlite: !["0", "false", "no", "off"].includes(
    String(process.env.COMMUNITY_USE_SQLITE ?? "1").toLowerCase()
  ),
  communitySqlitePath: (process.env.COMMUNITY_SQLITE_PATH ?? "").trim()
    ? path.resolve(process.env.COMMUNITY_SQLITE_PATH.trim())
    : path.join(_collectorRoot, "data", "community.sqlite"),
  /** Telegram /telegram 实时消息本地库（切 tab / 重启可续拉） */
  telegramLiveSqlitePath: (process.env.TELEGRAM_LIVE_SQLITE_PATH ?? "").trim()
    ? path.resolve(process.env.TELEGRAM_LIVE_SQLITE_PATH.trim())
    : path.join(_collectorRoot, "data", "telegram-live.sqlite"),
  /** collect:ui 启动时自动守护 telegram/listen.py（默认开；与 /telegram 页面无关） */
  telegramListenAutoStart: !["0", "false", "no", "off"].includes(
    String(process.env.TELEGRAM_LISTEN_AUTO_START ?? "1").toLowerCase(),
  ),
  telegramSupervisorIntervalMs: Number(process.env.TELEGRAM_SUPERVISOR_INTERVAL_MS ?? 20_000),
  /** 社区聊天室媒体上传目录 */
  communityChatUploadDir: (process.env.COMMUNITY_CHAT_UPLOAD_DIR ?? "").trim()
    ? path.resolve(process.env.COMMUNITY_CHAT_UPLOAD_DIR.trim())
    : path.join(_collectorRoot, "uploads", "chat"),
  communityChatImageMaxBytes: Number(process.env.COMMUNITY_CHAT_IMAGE_MAX_BYTES ?? 5 * 1024 * 1024),
  communityChatVideoMaxBytes: Number(process.env.COMMUNITY_CHAT_VIDEO_MAX_BYTES ?? 20 * 1024 * 1024),
  /**
   * Google Identity Services Client ID（OAuth 网页客户端）。
   * 用于社区「使用 Google 登录」；留空则仅邮箱密码。
   */
  communityGoogleClientId: (process.env.COMMUNITY_GOOGLE_CLIENT_ID ?? "").trim(),
  /** 邮箱密码注册是否仅允许 Gmail / Googlemail */
  communityEmailRequireGoogleMail: ["1", "true", "yes", "on"].includes(
    String(process.env.COMMUNITY_EMAIL_REQUIRE_GOOGLE_MAIL ?? "0").toLowerCase()
  ),
  /** 公共聊天粘贴 URL 时抓取 og/meta 预览 */
  communityLinkPreviewEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.COMMUNITY_LINK_PREVIEW ?? "1").toLowerCase()
  ),
  communityLinkPreviewTimeoutMs: Math.min(
    15_000,
    Math.max(2_000, Number(process.env.COMMUNITY_LINK_PREVIEW_TIMEOUT_MS ?? 6_000) || 6_000)
  ),
  communityLinkPreviewMaxBytes: Math.min(
    2 * 1024 * 1024,
    Math.max(64 * 1024, Number(process.env.COMMUNITY_LINK_PREVIEW_MAX_BYTES ?? 512 * 1024) || 512 * 1024)
  ),
  /**
   * 本地 CDP 抓取已登录 X/Twitter 列表最新帖（默认端口 9222，可改 9223）。
   * 列表：逗号分隔的 listId 或 https://x.com/i/lists/{id}
   */
  twitterCdpEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.TWITTER_CDP_ENABLED ?? "1").toLowerCase()
  ),
  twitterCdpPort: Number(process.env.TWITTER_CDP_PORT ?? 9222) || 9222,
  twitterCdpHost: (process.env.TWITTER_CDP_HOST ?? "127.0.0.1").trim() || "127.0.0.1",
  twitterCdpIntervalMs: Math.max(
    30_000,
    Number(process.env.TWITTER_CDP_INTERVAL_MS ?? 120_000) || 120_000
  ),
  twitterCdpTelegram: !["0", "false", "no", "off"].includes(
    String(process.env.TWITTER_CDP_TELEGRAM ?? "1").toLowerCase()
  ),
  twitterCdpLists: parseIdList(process.env.TWITTER_CDP_LISTS ?? ""),
  twitterCdpMaxPerList: Math.min(50, Math.max(5, Number(process.env.TWITTER_CDP_MAX_PER_LIST ?? 20) || 20)),
  /** 跟单建卡互斥源：`kolvip`（默认）| `discord`（`SIGNAL_INGEST_SOURCE`） */
  signalIngestSource: signalIngestSourceFromEnv(),
  /**
   * 巨鲸 kolvip.vip 信号源。`SIGNAL_INGEST_SOURCE=kolvip` 时默认开 API；切 Discord 建卡：`SIGNAL_INGEST_SOURCE=discord`。
   */
  kolvipApiEnabled: (() => {
    const raw = process.env.KOLVIP_API_ENABLED;
    if (raw != null && String(raw).trim() !== "") return envTruthy(raw);
    return signalIngestSourceFromEnv() === "kolvip";
  })(),
  kolvipCdpEnabled: (() => {
    const raw = process.env.KOLVIP_CDP_ENABLED;
    if (raw != null && String(raw).trim() !== "") return envTruthy(raw);
    return false;
  })(),
  kolvipSignalEnabled: (() => {
    const on = (k) => envTruthy(process.env[k]);
    if (on("KOLVIP_ENABLED") || on("KOLVIP_API_ENABLED") || on("KOLVIP_CDP_ENABLED")) return true;
    if (String(process.env.KOLVIP_ENABLED ?? "").trim().toLowerCase() === "0") return false;
    if (signalIngestSourceFromEnv() !== "kolvip") return false;
    const apiRaw = process.env.KOLVIP_API_ENABLED;
    const cdpRaw = process.env.KOLVIP_CDP_ENABLED;
    const apiOn = apiRaw != null && String(apiRaw).trim() !== "" ? envTruthy(apiRaw) : true;
    const cdpOn = cdpRaw != null && String(cdpRaw).trim() !== "" ? envTruthy(cdpRaw) : false;
    return apiOn || cdpOn;
  })(),
  /** api | cdp | auto — auto 优先 HTTP，失败且 CDP 开则回退 DOM */
  kolvipFetchMode: (() => {
    const m = String(process.env.KOLVIP_FETCH_MODE ?? "auto").trim().toLowerCase();
    if (m === "api" || m === "cdp" || m === "auto") return m;
    return "auto";
  })(),
  kolvipApiBaseUrl: (
    process.env.KOLVIP_API_BASE_URL ?? "https://kolvip.vip/api-v1"
  ).trim(),
  kolvipApiWtoken: (process.env.KOLVIP_API_WTOKEN ?? "").trim(),
  kolvipApiTokenFile: (process.env.KOLVIP_API_TOKEN_FILE ?? "").trim(),
  kolvipApiLocalStorageFile: (process.env.KOLVIP_API_LOCALSTORAGE_FILE ?? "").trim(),
  kolvipApiCdpTokenSync: !["0", "false", "no", "off"].includes(
    String(process.env.KOLVIP_API_CDP_TOKEN_SYNC ?? "1").toLowerCase()
  ),
  /** file-first（默认）| cdp-first — CDP 优先时用 KOLVIP_CDP_CONNECT_URL（如 :9223），文件作兜底 */
  kolvipApiWtokenPriority: (() => {
    const raw = String(process.env.KOLVIP_API_WTOKEN_PRIORITY ?? "file-first")
      .trim()
      .toLowerCase();
    if (raw === "cdp-first" || raw === "cdp") return "cdp-first";
    return "file-first";
  })(),
  kolvipApiTimeoutMs: Math.max(
    3000,
    Number(process.env.KOLVIP_API_TIMEOUT_MS ?? 15_000) || 15_000
  ),
  kolvipApiChannelDelayMs: Math.max(
    0,
    Number(process.env.KOLVIP_API_CHANNEL_DELAY_MS ?? 800) || 800
  ),
  kolvipApiMaxPerChannel: Math.min(
    150,
    Math.max(5, Number(process.env.KOLVIP_API_MAX_PER_CHANNEL ?? 40) || 40)
  ),
  kolvipPollIntervalMs: Math.max(
    15_000,
    Number(
      process.env.KOLVIP_POLL_INTERVAL_MS ??
        process.env.KOLVIP_API_INTERVAL_MS ??
        process.env.KOLVIP_CDP_INTERVAL_MS ??
        90_000
    ) || 90_000
  ),
  kolvipWsEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.KOLVIP_WS_ENABLED ?? "1").toLowerCase()
  ),
  kolvipWsReconnectMs: Math.max(
    1000,
    Number(process.env.KOLVIP_WS_RECONNECT_MS ?? 5_000) || 5_000
  ),
  /** WS 已连接时 HTTP 轮询降为兜底（漏消息、断线补偿） */
  kolvipPollDeferWhenWs: !["0", "false", "no", "off"].includes(
    String(process.env.KOLVIP_POLL_DEFER_WHEN_WS ?? "1").toLowerCase()
  ),
  kolvipPollFallbackMs: Math.max(
    60_000,
    Number(process.env.KOLVIP_POLL_FALLBACK_MS ?? 600_000) || 600_000
  ),
  /** 留空则沿用 CDP_CONNECT_URL（同一 Chrome :9222，需已登录 kolvip.vip/web） */
  kolvipCdpConnectUrl: (process.env.KOLVIP_CDP_CONNECT_URL ?? "").trim(),
  kolvipWebUrl: (process.env.KOLVIP_WEB_URL ?? "https://kolvip.vip/web").trim(),
  /** 图片附件 origin；留空则从 KOLVIP_WEB_URL 推导（如 https://kolvip.vip） */
  kolvipAssetOrigin: (process.env.KOLVIP_ASSET_ORIGIN ?? "").trim(),
  kolvipCdpIntervalMs: Math.max(
    15_000,
    Number(process.env.KOLVIP_CDP_INTERVAL_MS ?? 90_000) || 90_000
  ),
  kolvipCdpMaxPerChannel: Math.min(
    80,
    Math.max(5, Number(process.env.KOLVIP_CDP_MAX_PER_CHANNEL ?? 40) || 40)
  ),
  kolvipBypassDiscordSignals: (() => {
    const explicit = (
      process.env.KOLVIP_BYPASS_DISCORD_SIGNALS ??
      process.env.KOLVIP_CDP_BYPASS_DISCORD_SIGNALS ??
      ""
    ).trim();
    if (explicit) return envTruthy(explicit);
    return signalIngestSourceFromEnv() === "kolvip";
  })(),
  /** 非精选频道建卡扫描（虚拟 channelId，不推 TG） */
  kolvipScanEvalEnabled: !["0", "false", "no", "off"].includes(
    String(process.env.KOLVIP_SCAN_EVAL_ENABLED ?? "1").toLowerCase()
  ),
  kolvipBackfillDays: Math.min(
    90,
    Math.max(7, Number(process.env.KOLVIP_BACKFILL_DAYS ?? 30) || 30)
  ),
  kolvipBackfillAllChannels: !["0", "false", "no", "off"].includes(
    String(process.env.KOLVIP_BACKFILL_ALL_CHANNELS ?? "1").toLowerCase()
  ),
  /** 非空覆盖默认 8 频道；格式 `1,4,8` 或 `16:1562351038277619783` */
  kolvipChannelMappings: parseKolvipChannelIdsEnv(process.env.KOLVIP_CHANNEL_IDS ?? ""),
  /** 巨鲸 DOM 历史回溯骨架（默认关；大批量请配合 KOLVIP_BACKFILL_SHADOW=1） */
  kolvipBackfillEnabled: ["1", "true", "yes", "on"].includes(
    String(process.env.KOLVIP_BACKFILL_ENABLED ?? "0").toLowerCase()
  ),
  kolvipBackfillShadow: !["0", "false", "no", "off"].includes(
    String(process.env.KOLVIP_BACKFILL_SHADOW ?? "1").toLowerCase()
  ),
  kolvipBackfillPilotChannelId: (process.env.KOLVIP_BACKFILL_PILOT_CHANNEL_ID ?? "").trim(),
  kolvipBackfillBatchSize: Math.min(
    200,
    Math.max(5, Number(process.env.KOLVIP_BACKFILL_BATCH_SIZE ?? 40) || 40)
  ),
  kolvipBackfillDaysPerBatch: Math.min(
    7,
    Math.max(1, Number(process.env.KOLVIP_BACKFILL_DAYS_PER_BATCH ?? 3) || 3)
  ),
  kolvipBackfillChannelCooldownMs: Math.max(
    30_000,
    Number(process.env.KOLVIP_BACKFILL_CHANNEL_COOLDOWN_MS ?? 120_000) || 120_000
  ),
  kolvipBackfillBatchCooldownMs: Math.max(
    15_000,
    Number(process.env.KOLVIP_BACKFILL_BATCH_COOLDOWN_MS ?? 60_000) || 60_000
  ),
  kolvipBackfillTickMs: Math.max(
    10_000,
    Number(process.env.KOLVIP_BACKFILL_TICK_MS ?? 45_000) || 45_000
  ),
  kolvipBackfillMaxRetries: Math.min(
    8,
    Math.max(0, Number(process.env.KOLVIP_BACKFILL_MAX_RETRIES ?? 3) || 3)
  ),
  /** 博主胜率本地镜像定时同步（0=关）；默认 2 分钟，与线上面板 refresh 同级 */
  kolvipSigSyncIntervalMs: Math.max(
    0,
    Number(process.env.KOLVIP_SIG_SYNC_INTERVAL_MS ?? 120_000) || 0
  ),
  /** OI → Telegram 形态卡片回测（validate backtestPolicy=telegram_oi） */
  tgSignalBacktestMajorStepPct: Number(process.env.TG_SIGNAL_BACKTEST_MAJOR_STEP_PCT ?? 0.5),
  tgSignalBacktestMajorInitialH: Number(process.env.TG_SIGNAL_BACKTEST_MAJOR_INITIAL_H ?? 3),
  tgSignalBacktestMajorExtendH: Number(process.env.TG_SIGNAL_BACKTEST_MAJOR_EXTEND_H ?? 3),
  tgSignalBacktestMajorExtendOnStep: ["1", "true", "yes", "on"].includes(
    String(process.env.TG_SIGNAL_BACKTEST_MAJOR_EXTEND_ON_STEP ?? "0").toLowerCase()
  ),
  tgSignalBacktestAltStepPct: Number(process.env.TG_SIGNAL_BACKTEST_ALT_STEP_PCT ?? 3),
  tgSignalBacktestAltInitialH: Number(process.env.TG_SIGNAL_BACKTEST_ALT_INITIAL_H ?? 3),
  tgSignalBacktestAltExtendH: Number(process.env.TG_SIGNAL_BACKTEST_ALT_EXTEND_H ?? 3),
  tgSignalBacktestAltExtendOnStep: !["0", "false", "no", "off"].includes(
    String(process.env.TG_SIGNAL_BACKTEST_ALT_EXTEND_ON_STEP ?? "1").toLowerCase()
  ),
  tgSignalBacktestMaxH: Number(process.env.TG_SIGNAL_BACKTEST_MAX_H ?? 24),
  /**
   * Telegram 交易信号 → python-ai-operate（AI 短评 + OI 截图 + CDP 发布）
   * 默认关；开启后需本机 console.py :8787 + Chrome CDP。
   */
  tradeSignalAiPublishEnabled: ["1", "true", "yes", "on"].includes(
    String(process.env.TRADE_SIGNAL_AI_PUBLISH ?? "0").toLowerCase()
  ),
  tradeSignalAiPublishUrl: (
    process.env.TRADE_SIGNAL_AI_PUBLISH_URL ?? "http://127.0.0.1:8787"
  ).trim(),
  tradeSignalAiPublishToken: (process.env.TRADE_SIGNAL_AI_PUBLISH_TOKEN ?? "").trim(),
  /** 卡片合并更新（补 TP/SL）是否再次推 Telegram；默认关，避免同卡重复 */
  telegramPushOnCardUpdate: ["1", "true", "yes", "on"].includes(
    String(process.env.TELEGRAM_PUSH_ON_CARD_UPDATE ?? "0").toLowerCase(),
  ),
  /** 卡片合并更新是否再次走 trade-signal CDP；默认关 */
  tradeSignalAiPublishOnUpdate: ["1", "true", "yes", "on"].includes(
    String(process.env.TRADE_SIGNAL_AI_PUBLISH_ON_UPDATE ?? "0").toLowerCase(),
  ),
  /** 同频道同币种 CDP 最短间隔（毫秒，默认 180000） */
  tradeSignalCdpSymbolCooldownMs: Math.max(
    60_000,
    Number(process.env.TRADE_SIGNAL_CDP_SYMBOL_COOLDOWN_MS ?? 180_000),
  ),
  tradeSignalAiPublishPlatforms: parseIdList(
    process.env.TRADE_SIGNAL_AI_PUBLISH_PLATFORMS ?? ""
  ),
};
