/**
 * 信号卡片执行结果：信号计划 vs 实际成交。
 */

import { resolveTradeDirection } from "./card-direction.js";

/** @typedef {{
 *   entryPrice: string,
 *   takeProfitPrices: string[],
 *   stopLossPrice: string,
 *   exitPlan?: Record<string, unknown>,
 * }} SignalTradeLeg */

/** @typedef {{
 *   buyPrice: string,
 *   sellPrice: string,
 *   takeProfitPrices: string[],
 *   stopLossPrice: string,
 *   exitPrice: string,
 *   closedAt: string | null,
 * }} SignalActualLeg */

/** @typedef {{
 *   symbol: string,
 *   direction: string,
 *   planned: SignalTradeLeg,
 *   actual: SignalActualLeg,
 *   outcome: string,
 *   outcomeNote: string,
 * }} SignalExecution */

/** @returns {SignalTradeLeg} */
export function emptyTradeLeg() {
  return { entryPrice: "", takeProfitPrices: [], stopLossPrice: "", exitPlan: undefined };
}

/** @returns {SignalActualLeg} */
export function emptyActualLeg() {
  return {
    buyPrice: "",
    sellPrice: "",
    takeProfitPrices: [],
    stopLossPrice: "",
    exitPrice: "",
    closedAt: null,
  };
}

/** @returns {SignalExecution} */
export function emptyExecution() {
  return {
    symbol: "",
    direction: "",
    planned: emptyTradeLeg(),
    actual: emptyActualLeg(),
    outcome: "pending",
    outcomeNote: "",
  };
}

/** @param {unknown} v @returns {string[]} */
export function normalizePriceList(v) {
  if (Array.isArray(v)) return v.map((x) => String(x ?? "").trim()).filter(Boolean);
  const s = String(v ?? "").trim();
  if (!s) return [];
  return s
    .split(/[,，;\s]+/)
    .map((x) => x.trim())
    .filter(Boolean);
}

/** @param {unknown} leg @returns {SignalTradeLeg} */
export function normalizeTradeLeg(leg) {
  if (!leg || typeof leg !== "object") return emptyTradeLeg();
  const o = /** @type {Record<string, unknown>} */ (leg);
  const exitPlan =
    o.exitPlan && typeof o.exitPlan === "object" && !Array.isArray(o.exitPlan)
      ? /** @type {Record<string, unknown>} */ (o.exitPlan)
      : undefined;
  return {
    entryPrice: String(o.entryPrice ?? o.entry ?? "").trim(),
    takeProfitPrices: normalizePriceList(o.takeProfitPrices ?? o.takeProfits ?? o.targets),
    stopLossPrice: String(o.stopLossPrice ?? o.stopLoss ?? "").trim(),
    ...(exitPlan ? { exitPlan } : {}),
  };
}

/** @param {unknown} leg @returns {SignalActualLeg} */
export function normalizeActualLeg(leg) {
  if (!leg || typeof leg !== "object") return emptyActualLeg();
  const o = /** @type {Record<string, unknown>} */ (leg);
  const closedAt = o.closedAt ?? o.closed_at;
  return {
    buyPrice: String(o.buyPrice ?? o.buy ?? "").trim(),
    sellPrice: String(o.sellPrice ?? o.sell ?? "").trim(),
    takeProfitPrices: normalizePriceList(o.takeProfitPrices ?? o.takeProfits),
    stopLossPrice: String(o.stopLossPrice ?? o.stopLoss ?? "").trim(),
    exitPrice: String(o.exitPrice ?? o.exit ?? "").trim(),
    closedAt: closedAt ? String(closedAt) : null,
  };
}

/** @param {Record<string, unknown> | null | undefined} parsed */
export function executionFromParsed(parsed) {
  if (!parsed || typeof parsed !== "object") return emptyExecution();
  const p = parsed;
  const symbol = String(p.symbol ?? p.asset ?? "").trim();
  const direction = String(p.direction ?? "").trim();
  const entryRaw =
    p.entry ??
    (Array.isArray(p.entries) ? p.entries.join(" / ") : "") ??
    p.entryPrice ??
    "";
  const tpRaw = p.targets ?? p.takeProfits ?? p.takeProfit;
  const planned = normalizeTradeLeg({
    entryPrice: entryRaw,
    takeProfitPrices: tpRaw,
    stopLossPrice: p.stopLoss ?? p.stop_loss,
  });
  return { symbol, direction, planned, actual: emptyActualLeg(), outcome: "pending", outcomeNote: "" };
}

/** @param {unknown} v */
function nonBlank(v) {
  return String(v ?? "").trim();
}

/**
 * planned 为空时，用同一条信号的 parsed 补入场/止盈/止损。
 * 开放建卡把 stopLoss 放在扁平字段和 parsedJson 上，不能让空的 planned.stopLossPrice 盖掉它们。
 * @param {SignalExecution} ex
 * @param {unknown} parsedJson
 */
function fillExecutionBlanks(ex, parsedJson) {
  if (!parsedJson || typeof parsedJson !== "object" || Array.isArray(parsedJson)) return ex;
  const from = executionFromParsed(/** @type {Record<string, unknown>} */ (parsedJson));
  if (!nonBlank(ex.symbol)) ex.symbol = from.symbol;
  if (!nonBlank(ex.direction)) ex.direction = from.direction;
  if (!nonBlank(ex.planned.entryPrice)) ex.planned.entryPrice = from.planned.entryPrice;
  if (!nonBlank(ex.planned.stopLossPrice)) ex.planned.stopLossPrice = from.planned.stopLossPrice;
  if (!ex.planned.takeProfitPrices.length && from.planned.takeProfitPrices.length) {
    ex.planned.takeProfitPrices = from.planned.takeProfitPrices;
  }
  return ex;
}

/** @param {unknown} raw @param {unknown} [parsedJson] @returns {SignalExecution} */
export function normalizeExecution(raw, parsedJson) {
  let ex = raw;
  if (typeof ex === "string") {
    try {
      ex = JSON.parse(ex);
    } catch {
      ex = null;
    }
  }
  if (ex && typeof ex === "object") {
    const o = /** @type {Record<string, unknown>} */ (ex);
    if (o.planned || o.actual) {
      return fillExecutionBlanks(
        {
          symbol: String(o.symbol ?? ""),
          direction: String(o.direction ?? ""),
          planned: normalizeTradeLeg(o.planned),
          actual: normalizeActualLeg(o.actual),
          outcome: String(o.outcome ?? "pending") || "pending",
          outcomeNote: String(o.outcomeNote ?? ""),
        },
        parsedJson
      );
    }
    return fillExecutionBlanks(
      {
        symbol: String(o.symbol ?? ""),
        direction: String(o.direction ?? ""),
        planned: normalizeTradeLeg({
          entryPrice: o.entryPrice ?? o.entry,
          takeProfitPrices: o.takeProfitPrices ?? o.takeProfits ?? o.targets,
          stopLossPrice: o.stopLossPrice ?? o.stopLoss,
        }),
        actual: normalizeActualLeg({
          buyPrice: o.actualBuyPrice ?? o.buyPrice,
          sellPrice: o.actualSellPrice ?? o.sellPrice,
          takeProfitPrices: o.actualTakeProfitPrices,
          stopLossPrice: o.actualStopLossPrice,
          exitPrice: o.actualExitPrice ?? o.exitPrice,
          closedAt: o.closedAt,
        }),
        outcome: String(o.outcome ?? "pending") || "pending",
        outcomeNote: String(o.outcomeNote ?? ""),
      },
      parsedJson
    );
  }
  return executionFromParsed(
    parsedJson && typeof parsedJson === "object"
      ? /** @type {Record<string, unknown>} */ (parsedJson)
      : null
  );
}

/** @param {SignalExecution} ex */
export function formatManualRawContent(ex) {
  const tps = ex.planned.takeProfitPrices.length ? ex.planned.takeProfitPrices.join(", ") : "-";
  return [
    `手动信号 ${ex.symbol || "—"}`,
    `方向: ${ex.direction || "-"}`,
    `计划入场: ${ex.planned.entryPrice || "-"}`,
    `计划止盈: ${tps}`,
    `计划止损: ${ex.planned.stopLossPrice || "-"}`,
    `结果: ${outcomeLabel(ex.outcome)}`,
  ].join("\n");
}

/** @param {string} outcome */
export function outcomeLabel(outcome) {
  switch (outcome) {
    case "take_profit":
      return "止盈";
    case "stop_loss":
      return "止损";
    case "manual_close":
      return "手动平仓";
    case "cancelled":
      return "已取消";
    default:
      return "进行中";
  }
}

/** @param {Record<string, unknown>} row */
export function summarizeCardExecution(row) {
  const ex = normalizeExecution(row.execution_json ?? row.executionJson, row.parsed_json ?? row.parsedJson);
  return { execution: ex, outcome: ex.outcome };
}

/** @param {unknown} v @returns {number | null} */
function parseEvalPrice(v) {
  const n = Number(String(v ?? "").trim().replace(/,/g, ""));
  return Number.isFinite(n) && n > 0 ? n : null;
}

/**
 * buy/sell → 入场/出场。标准约定 buy=入场、sell=出场（清算/OI 回写均如此）。
 * 旧数据若反存，用 planned.entry 或 actual.entryPrice 贴近的一侧判定。
 * @param {{ buyPrice?: string, sellPrice?: string, entryPrice?: string }} actual
 * @param {string} [direction]
 * @param {{ entryHint?: unknown, plannedEntry?: unknown }} [opts]
 */
export function resolveActualEntryExit(actual, direction, opts) {
  const buy = parseEvalPrice(actual?.buyPrice);
  const sell = parseEvalPrice(actual?.sellPrice);
  const side = resolveTradeDirection(direction);
  if (buy == null || sell == null || !side) {
    return { entry: buy, exit: sell, side };
  }
  const entryHint = parseEvalPrice(
    opts?.entryHint ?? opts?.plannedEntry ?? actual?.entryPrice
  );
  if (entryHint != null) {
    const buyDist = Math.abs(buy - entryHint);
    const sellDist = Math.abs(sell - entryHint);
    if (buyDist <= sellDist) return { entry: buy, exit: sell, side };
    return { entry: sell, exit: buy, side };
  }
  return { entry: buy, exit: sell, side };
}

/**
 * 用户已填写入场/出场且可计算收益率 → 无需自动回测。
 * @param {SignalExecution} ex
 */
export function hasEvaluatedYield(ex) {
  const a = ex?.actual;
  if (!a) return false;
  const { entry, exit, side } = resolveActualEntryExit(a, ex.direction);
  if (entry == null || exit == null || !side) return false;
  return true;
}

export const OUTCOME_VALUES = ["pending", "take_profit", "stop_loss", "manual_close", "cancelled"];
